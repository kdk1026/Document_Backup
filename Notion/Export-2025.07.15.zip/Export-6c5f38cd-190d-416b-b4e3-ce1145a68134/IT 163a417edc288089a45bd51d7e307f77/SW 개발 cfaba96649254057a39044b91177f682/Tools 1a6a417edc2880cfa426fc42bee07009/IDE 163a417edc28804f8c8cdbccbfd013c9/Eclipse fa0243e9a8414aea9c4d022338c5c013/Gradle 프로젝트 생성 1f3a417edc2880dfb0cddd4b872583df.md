# Gradle 프로젝트 생성

- Gradle 버전 6.6.1 이후로는 프로젝트 워크스페이스와 lib 워크스페이스가 생성됨
- Gradle 프로젝트 생성 시, `Override workspace settings` 체크, `Specific Gradle version` 을 `6.6.1` 선택 후 생성
    - `java home` 디렉토리르 `JDK11` 로 지정해야 함
    - 프로젝트 생성 후, 업그레이드 된 버전으로 변경