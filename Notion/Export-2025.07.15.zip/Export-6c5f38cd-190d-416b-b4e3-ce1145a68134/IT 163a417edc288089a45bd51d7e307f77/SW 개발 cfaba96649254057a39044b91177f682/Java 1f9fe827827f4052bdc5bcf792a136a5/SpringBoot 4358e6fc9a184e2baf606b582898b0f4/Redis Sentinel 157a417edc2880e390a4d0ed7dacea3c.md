# Redis Sentinel

- application.yml

```jsx
spring:
  data:
    redis:
      password: devRedis0717!
      sentinel:
        master: LWdevRedis
        nodes: 172.16.127.7:26379,172.16.127.7:26389,172.16.127.7:26399 
        password: devRedis0717!
      database: 15
```

- RedisConfig

```jsx
@Profile("!local")
@Configuration
public class RedisConfig {

	@Value("${spring.data.redis.sentinel.master}")
    private String master;

    @Value("${spring.data.redis.sentinel.nodes}")
    private String nodes;

    @Value("${spring.data.redis.password}")
    private String password;
    
    @Value("${spring.data.redis.sentinel.password}")
    private String sentinelPassword;

    @Value("${spring.data.redis.database}")
    private int database;

	@Bean
	RedisConnectionFactory redisConnectionFactory() {
		RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration()
			.master(master);

	for ( String node : nodes.split(",") ) {
            String[] parts = node.split(":");
            sentinelConfig.sentinel(parts[0], Integer.parseInt(parts[1]));
            sentinelConfig.setSentinelPassword(sentinelPassword);
        }

	sentinelConfig.setPassword(RedisPassword.of(password));
//        sentinelConfig.setDatabase(database);

	return new LettuceConnectionFactory(sentinelConfig);
	}

	@Bean
	RedisTemplate<String, Object> redisTemplate() {
		RedisTemplate<String, Object> template = new RedisTemplate<>();
		template.setConnectionFactory(redisConnectionFactory());
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        return template;
	}

}
```