# 퍼블 hook기반 Alert JS에서 사용하기

- index.html

```jsx
  <body class="adv-hp-ui">
    <div id="root" class="root"></div>
    <div id="alertRoot" class="modalRoot"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
```

- AlertComponent

```jsx
import { useDispatch, useSelector } from "react-redux";
import { Alert } from "../../shared/components";
import { createPortal } from "react-dom";
import { closeJsAlert } from "@/store/reducers/AlertReducer";

function AlertComponent() {
    const dispatch = useDispatch();
    const { isOpen, message, options } = useSelector((state) => state.alert);

    const alertRoot = typeof window !== "undefined" && document.querySelector("#alertRoot");

    const handleClose = () => {
        dispatch(closeJsAlert()); // Redux 상태에서 팝업 닫기
        if (options.onOk) {
            options.onOk(); // onOk 콜백 호출
        }
    };

    return createPortal(
        <Alert
            text={message}
            isOpen={isOpen ? "open" : "close"}
            setIsOpen={handleClose}
            {...options}
        />,
        alertRoot
    )
}

export default AlertComponent;
```

- App.jsx

```jsx
    <div>
      <BrowserRouter>
        <CommonRoute />
        <AlertComponent />
      </BrowserRouter>
    </div>
```

- AlertReducer

```jsx
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    isOpen: false,
    message: '',
    options: {},
};

const alertSlice = createSlice({
    name: "alert",
    initialState,
    reducers: {
        openJsAlert(state, action) {
            state.isOpen = true;
            state.message = action.payload.message || '';
            state.options = action.payload.options || {};
        },
        closeJsAlert(state) {
            state.isOpen = false;
            state.message = '';
            state.options = {};
        }
    }
});

export const { openJsAlert, closeJsAlert } = alertSlice.actions;
export default alertSlice.reducer;
```

- jsAlert.js

```jsx
import store from "@/store";
import { openJsAlert } from "@/store/reducers/AlertReducer";

export const showAlert = (message, onOk) => {
    store.dispatch(
        openJsAlert({
            message,
            options: { onOk }
        })
    );
}
```

- JS 파일

```jsx
import store from "@/store";

showAlert('URL은 localhost, 127.0.0.1 또는 HTTPS여야 합니다.', () => {
        store.dispatch(closeJsAlert());
});
```