# FrontEnd 빌드

- 서버에 NodeJS, npm 설치되어 있어야 함

- Jenkins에 NodeJS Plugin 설치
    - Jenkins 관리 > Plugins > Available plugins > NodeJS 검색해서 설치
    
- Jenkins에 NodeJS경로 지정
    - Jenkins 관리 > Tools
    
- 프로젝트 생성
    - 새로운 Item > Freestyle project
        - 소스 코드 관리
        - Build Steps > Add build step > Execute shell
            
            ```bash
            cd /var/jenkins_home/workspace/react-basic
            npm install
            npm run build
            cd /var/jenkins_home/workspace/react-basic/build
            cp -r * /var/www/html/react-basic/
            ```