# Code Templates Comments 설정

- Code Templates Comments 설정
    - Window > Preferences > Java > Code Style > Code Templates > Comments
        - Files > Edit > 제거
        - Types > Edit
        
        ```jsx
         /**
         * <pre>
         * -----------------------------------
         * 개정이력
         * -----------------------------------
         * ${date} ${user}	최초작성
         * </pre>
         * 
         *
         * @author ${user}
         */
        ```