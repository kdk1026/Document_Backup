# Let's Encrypt를 이용한 무료 SSL 인증서 적용

- Certbot 설치

```jsx
// RedHat 계열
$ sudo yum install epel-release
$ sudo yum install certbot python-certbot-apache

// Debian 계열
$ sudo apt-get install certbot python3-certbot-apache
```

- SSL 인증서 발급

```jsx
$ sudo certbot --apache
```

- SSL 인증서 자동 갱신 설정
    - 3개월마다 갱신 필요
    
    - 갱신 스크립트 작성
    
    ```jsx
    $ vi /etc/cron.daily/certbot-renew
    ```
    
    ```jsx
    #!/bin/bash
    certbot renew --quiet
    ```
    
    - 스크립트에 실행 권한 부여
    
    ```jsx
    $ sudo chmod +x /etc/cron.daily/certbot-renew
    ```
    
    - 일반적으로 `/etc/cron.daily` 디렉토리 아래에 있는 모든 스크립트는 매일 한 번 실행