# axios interceptor response 에러 처리

```jsx
...
instance.interceptors.response.use(
	(response) => {

		return response;
	},
	async (error) => {
		
		if ( error.response?.status === 401 ) {
			if ( isTokenExpired() ) {
				await tokenRefresh();
			}
			
			const accessToken = getToken();
			
			error.config.headers = {
				'Content-Type': 'application/json',
				Authorization: `Bearer ${accessToken}`
			};
			
			const response = await axios.request(error.config);
			return response;
		} else {
			onErrorCase(error);
		}

		return Promise.reject(error);
	}
);

const onErrorCase = (error) => {
	if ( error.code === 'ERR_NETWORK' ) {
		onError(999, `에러가 발생했습니다. ${error.message}`);
	}

	if ( error.code === 'ECONNABORTED' ) {
		onError(998, `요청이 만료되었습니다. ${error.message}`);
	}
    
	const { status, statusText } = error.response;
	
	switch (status) {
		case 400:
			onError(status, "잘못된 요청입니다.");
			break;
		case 401:
			onError(status, "인증 실패입니다.");
			break;
		case 403:
			onError(status, "권한이 없습니다.");
			break;
		case 404:
			onError(status, "찾을 수 없는 URL 입니다.");
			break;
		case 500:
			onError(status, "서버 오류입니다.");
			break;
		default:
			onError(status, `에러가 발생했습니다. ${error.message}`);
	}	
};

const onError = (status, message) => {
  const error = { status, message };
  throw error;
};

/*
	호출 하는 곳
	
	const registerEvent = async (id, name, password) => {
		try {
		  const res = await axios.post('users/register', { id, name, password });
		  ...
		} catch (err) {
		  console.log(err.status, err.message);
		}
	};	
*/
```