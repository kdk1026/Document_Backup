# jQuery UI Datepicker 다국어

```html
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>jQuery UI</title>
        <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css"/>
        <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
        <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>

        <!-- jQuery UI 국제화 대응을 위한 라이브러리 (다국어) -->
        <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/i18n/jquery-ui-i18n.min.js"></script>

        <script>
            $(function() {
              $.datepicker.setDefaults($.datepicker.regional['ko']); //datepicker 한국어로 사용하기 위한 언어설정
              $('#date').datepicker();
            });
        </script>
    </head>
    <body>
        <form>
          <input type="text" id="date" size="10" />
        </form>
    </body>
</html>
```