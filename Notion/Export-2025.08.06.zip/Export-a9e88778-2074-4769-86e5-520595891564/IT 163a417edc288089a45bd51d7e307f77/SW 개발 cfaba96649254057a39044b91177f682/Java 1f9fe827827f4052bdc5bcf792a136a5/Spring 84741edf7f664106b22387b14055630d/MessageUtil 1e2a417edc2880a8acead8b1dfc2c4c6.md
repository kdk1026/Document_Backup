# MessageUtil

- Spring LocaleResolver를 통해 다국어를 처리하지 않는 경우

```jsx
public class MessageUtil {

	private static ResourceBundleMessageSource messageSource;

	static {
		messageSource = new ResourceBundleMessageSource();
		messageSource.setBasename("messages/message");
		messageSource.setDefaultEncoding("UTF-8");
	}

	public static String getMessage(String code, String languageCode) {
		languageCode = "jp".equals(languageCode) ? "ja" : languageCode;
		Locale locale = Locale.of(languageCode);
        return messageSource.getMessage(code, null, locale);
	}

}
```