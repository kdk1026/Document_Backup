# 부팅 USB Ventoy 보안부팅

- `Verification Failed : (0x1A) Security Violation` 에러
    - [https://buly.kr/8IvQ6oU](https://buly.kr/8IvQ6oU)