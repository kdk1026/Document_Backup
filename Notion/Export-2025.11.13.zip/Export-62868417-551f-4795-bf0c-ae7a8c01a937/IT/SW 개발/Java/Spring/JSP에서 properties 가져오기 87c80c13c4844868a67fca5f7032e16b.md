# JSP에서 properties 가져오기

```java
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
...

<spring:eval var="webSockertUrl" expression="@environment.getProperty('web.socket.url')" />
```