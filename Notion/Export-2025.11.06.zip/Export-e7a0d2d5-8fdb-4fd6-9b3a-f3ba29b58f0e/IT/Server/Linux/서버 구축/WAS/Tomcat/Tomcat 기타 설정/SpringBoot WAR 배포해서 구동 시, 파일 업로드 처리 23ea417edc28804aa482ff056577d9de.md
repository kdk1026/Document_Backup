# SpringBoot WAR 배포해서 구동 시, 파일 업로드 처리

- server.xml

```jsx
    <Connector port="8080" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443"
               maxParameterCount="-1"
               />
```

```jsx
    <Connector port="8443" protocol="org.apache.coyote.http11.Http11NioProtocol"
               maxThreads="150" SSLEnabled="true"
               maxParameterCount="1000"
               >
```

```jsx
    <Connector protocol="AJP/1.3"
               address="0.0.0.0"
               port="8009"
               redirectPort="8443"
               maxPostSize="-1"
               maxParameterCount="-1"
               maxPartCount="1000"
               secretRequired="false"
               />
```