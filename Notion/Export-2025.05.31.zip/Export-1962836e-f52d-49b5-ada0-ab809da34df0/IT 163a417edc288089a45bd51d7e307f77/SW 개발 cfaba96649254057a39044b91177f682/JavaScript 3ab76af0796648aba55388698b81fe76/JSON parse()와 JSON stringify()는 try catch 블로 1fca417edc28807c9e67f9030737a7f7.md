# JSON.parse()와 JSON.stringify()는 try...catch 블록과 함께 사용하는 것을 적극 권장

```jsx
const invalidJsonString = "{'name': 'Alice'}"; // JSON에서는 작은따옴표가 유효하지 않습니다.

try {
  const data = JSON.parse(invalidJsonString);
  console.log(data);
} catch (error) {
  console.error("JSON 파싱 실패:", error.message);
  // 에러를 적절하게 처리합니다. 예를 들어, 사용자에게 에러 메시지를 보여주거나
  // 기본값을 사용하도록 할 수 있습니다.
}
```

```jsx
const objWithCircularRef = {};
objWithCircularRef.a = objWithCircularRef; // 순환 참조

try {
  const jsonString = JSON.stringify(objWithCircularRef);
  console.log(jsonString);
} catch (error) {
  console.error("JSON 문자열 변환 실패:", error.message);
  // 에러를 처리하고, 필요하다면 로그를 남기거나 기본 문자열을 제공합니다.
}

const objWithBigInt = {
    value: 10n // BigInt
};

try {
    const jsonString = JSON.stringify(objWithBigInt);
    console.log(jsonString);
} catch (error) {
    console.error("JSON 문자열 변환 실패:", error.message);
}
```