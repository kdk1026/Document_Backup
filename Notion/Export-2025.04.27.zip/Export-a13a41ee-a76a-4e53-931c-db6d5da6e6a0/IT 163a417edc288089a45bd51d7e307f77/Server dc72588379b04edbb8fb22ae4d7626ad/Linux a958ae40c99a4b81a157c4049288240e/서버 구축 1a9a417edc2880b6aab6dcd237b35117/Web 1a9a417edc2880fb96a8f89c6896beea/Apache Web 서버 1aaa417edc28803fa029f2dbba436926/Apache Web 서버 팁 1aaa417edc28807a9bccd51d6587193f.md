# Apache Web 서버 팁

- Apache Web 서버 보안 설정
    - [https://m.blog.naver.com/godgodmin/221851224176](https://m.blog.naver.com/godgodmin/221851224176)
    
- http로 접속하면 https로
    - Redirect 옵션
    
    ```jsx
    <VirtualHost *:80>
        ServerName 사이트_도메인
    
        Redirect permanent / https://사이트_도메인/
    </VirtualHost>
    ```
    
    - RewirteRule 옵션
    
    ```jsx
    <VirtualHost *:80>
        ServerName 사이트_도메인
    
        RewriteEngine On
        RewriteCond %{HTTPS} !on
        RewriteRule ^(.*)$ https://%{HTTP_HOST}$1 [R=301,L]
    </VirtualHost>
    ```