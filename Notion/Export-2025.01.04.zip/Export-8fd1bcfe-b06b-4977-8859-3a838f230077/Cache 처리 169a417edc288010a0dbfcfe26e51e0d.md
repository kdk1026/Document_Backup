# Cache 처리

- pom.xml

```jsx
<!-- 캐시 처리 -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-cache</artifactId>
        </dependency>
        <dependency>
            <groupId>com.github.ben-manes.caffeine</groupId>
            <artifactId>caffeine</artifactId>
        </dependency>
```

- application.properties

```jsx
spring.cache.type=caffeine
```

- CacheConfig

```jsx
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.github.benmanes.caffeine.cache.Caffeine;
import java.util.concurrent.TimeUnit;

@Configuration
@EnableCaching
public class CacheConfig {
    @Bean
    public Caffeine<Object, Object> caffeineConfig() {
        return Caffeine.newBuilder()
                .expireAfterWrite(10, TimeUnit.MINUTES)
                .maximumSize(100);
    }
}
```

- Service

```jsx
// 키가 1개인 경우
@Cacheable(value = "lpointAuthInfoCache", key = "#acesTkn")
@Override
public AuthUserVo getAuthenticatedUser(String acesTkn) {

// 키가 n개인 경우
@Cacheable(value = "codeListCache", key = "#vo.codeWorkGrpId + '_' + #vo.codeGrpId")
@Override
public List<CodeVo> getCodeList(CodeParamVo vo) {
```