# 채널톡 (ChannelIO)

```jsx
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <script>
        (function () {
            var w = window;
            if (w.ChannelIO) {
              return (window.console.error || window.console.log || function () {})(
                "ChannelIO script included twice."
              );
            }
            var ch = function () {
              ch.c(arguments);
            };
            ch.q = [];
            ch.c = function (args) {
              ch.q.push(args);
            };
            w.ChannelIO = ch;
    
            function l() {
              if (w.ChannelIOInitialized) {
                return;
              }
              w.ChannelIOInitialized = true;
              var s = document.createElement("script");
              s.type = "text/javascript";
              s.async = true;
              s.src = "https://cdn.channel.io/plugin/ch-plugin-web.js";
              s.charset = "UTF-8";
              var x = document.getElementsByTagName("script")[0];
              x.parentNode.insertBefore(s, x);
            }
            if (document.readyState === "complete") {
              l();
            } else if (window.attachEvent) {
              window.attachEvent("onload", l);
            } else {
              window.addEventListener("DOMContentLoaded", l, false);
              window.addEventListener("load", l, false);
            }
          })();
          ChannelIO("boot", {
            pluginKey: "c06de1c8-cd49-4e78-be3f-50ced236efa4",
            customLauncherSelector: ".adv_chat_foot",
            hideChannelButtonOnBoot: true,
          });</script>
        </script>
</head>
<body>

    <div class="adv_chat_foot" onclick="ChannelIO('open')">
        채팅상담
    </div>

    <select onchange="handleChange(this)">
        <option value="ko">ko</option>
        <option value="en">en</option>
        <option value="ja">jp</option>
    </select>

    <script>
        const handleChange = (e) => {
            if ( window.ChannelIO ) {
                window.ChannelIO('updateUser', {
                    language: e.value
                });
            }
        };
    </script>

</body>
</html>
```