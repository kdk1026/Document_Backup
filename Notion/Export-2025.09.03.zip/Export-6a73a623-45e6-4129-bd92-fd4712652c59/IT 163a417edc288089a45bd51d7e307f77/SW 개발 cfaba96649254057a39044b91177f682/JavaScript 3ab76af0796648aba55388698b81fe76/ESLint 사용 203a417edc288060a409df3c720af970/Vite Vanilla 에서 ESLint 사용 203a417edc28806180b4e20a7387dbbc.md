# Vite Vanilla 에서 ESLint 사용

- ESLint 패키지 설치
    
    ```jsx
    # npm 사용 시
    npm install --save-dev eslint
    
    # yarn 사용 시
    yarn add --dev eslint
    ```
    
    - TypeScript 사용 시, 
    `@typescript-eslint/parser`, `@typescript-eslint/eslint-plugin` 등 필요

- ESLint 설정 파일 생성 및 구성
    
    ```jsx
    npx eslint --init
    ```
    

- package.json 스크립트 추가
    
    ```jsx
    ...
      "scripts": {
    	  ...
        "lint": "eslint .", // 현재 디렉토리의 모든 파일을 린트
        "lint:fix": "eslint . --fix" // 린트 오류를 자동으로 수정
      },
    ...
    ```