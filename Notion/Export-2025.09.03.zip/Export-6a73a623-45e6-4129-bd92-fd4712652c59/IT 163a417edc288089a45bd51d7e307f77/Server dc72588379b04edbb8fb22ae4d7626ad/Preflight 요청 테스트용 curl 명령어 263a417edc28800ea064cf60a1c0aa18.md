# Preflight 요청 테스트용 curl 명령어

```jsx
curl -X OPTIONS https://도메인/api/URI \
  -H "Origin: https://도메인" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: Content-Type"
```

- 이상 없는 경우, 명령어 정상 종료
- 이상 있는 경우, 응답 (WAF 차단 등)