# http로 접속하면 https로

```jsx
http {
    server {
        listen 80;
        server_name *.kello.com;

        return 301 https://$host$request_uri;
    }
}
```