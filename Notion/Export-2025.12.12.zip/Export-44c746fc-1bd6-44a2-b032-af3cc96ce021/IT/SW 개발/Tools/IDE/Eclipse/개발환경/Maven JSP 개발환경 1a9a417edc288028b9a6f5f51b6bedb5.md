# Maven JSP 개발환경

- 간단한 테스트 용도

- Eclipse 프로젝트 생성
    - Package Explorer 우클릭 > New > Maven Project
    - Next > Catalog: Internal > maven-archetype-webapp > Next
    - Group Id, Artifact Id, Version 설정