# SourceTree에서 Commit 되돌리기

- 절차
    - Commit 시점을 되돌릴 브랜치 체크아웃
    - History 확인해서 커밋을 되돌릴 시점 찾기
    - 우클릭 > `이 커밋까지 현재 브랜치를 초기화`
        - Mixed

- 강제 푸시
    - 도구 > 옵션 Git Tab > `강제 푸시 가능` 활성
    - `Push` 버튼 클릭 > `강제 푸시` 체크 > `Push` > `예`