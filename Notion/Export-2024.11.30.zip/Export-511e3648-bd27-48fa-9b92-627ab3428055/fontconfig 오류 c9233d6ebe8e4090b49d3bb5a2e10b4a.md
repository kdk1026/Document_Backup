# fontconfig 오류

- java.awt.Font 사용 시, 오류 발생 할 수 있음
- 예) SimpleCaptcha
- 서버에 fontconfig 설치해야 함

- RedHat 기반

```bash
yum install fontconfig
```

- Debian 기반

```bash
sudo apt-get update
sudo apt-get -y install fontconfig
```