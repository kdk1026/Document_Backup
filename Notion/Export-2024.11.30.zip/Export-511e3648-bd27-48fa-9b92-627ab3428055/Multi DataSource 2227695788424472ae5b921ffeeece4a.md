# Multi DataSource

- application-local.yaml

```java
spring:
  datasource:
    hikari:
      connection-timeout: 3000
      max-lifetime: 580000
      connection-test-query: SELECT 1
      validation-timeout: 3000
      maximum-pool-size: 10
  first:
    datasource:
      driverClassName: net.sf.log4jdbc.sql.jdbcapi.DriverSpy
      jdbc-url: 
      username: 
      password: 
  second:
    datasource:
      driverClassName: net.sf.log4jdbc.sql.jdbcapi.DriverSpy
      jdbc-url: 
      username: 
      password: 
```

- FirstDataSourceConfig

```java
@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = {"com.kdk.app.mapper.first.**"}, annotationClass = Mapper.class, sqlSessionFactoryRef = "firstSqlSessionFactory")
public class FirstDataSourceConfig {

	private static final String MYBATIS_CONFIG_LOCATION = "mybatis/configuration.xml";
	private static final String MYBATIS_MAPPER_LOCATION = "classpath:mybatis/mappers/first/**/*.xml";

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.hikari")
    HikariConfig firstHikariConfig() {
    	return new HikariConfig();
	}

    @Primary
    @Bean
    @ConfigurationProperties(prefix = "spring.first.datasource")
    DataSource firstDataSource() {
    	HikariDataSource firstDataSource = new HikariDataSource();

    	firstDataSource.setConnectionTimeout(this.firstHikariConfig().getConnectionTimeout());
    	firstDataSource.setMaxLifetime(this.firstHikariConfig().getMaxLifetime());
    	firstDataSource.setConnectionTestQuery(this.firstHikariConfig().getConnectionTestQuery());
    	firstDataSource.setValidationTimeout(this.firstHikariConfig().getValidationTimeout());
    	firstDataSource.setMaximumPoolSize(this.firstHikariConfig().getMaximumPoolSize());

    	return firstDataSource;
	}

    @Primary
    @Bean
    PlatformTransactionManager firstTransactionManager(@Qualifier("firstDataSource") DataSource dataSource) {
    	return new DataSourceTransactionManager(dataSource);
	}

    @Primary
    @Bean
    SqlSessionFactory firstSqlSessionFactory(@Qualifier("firstDataSource") DataSource dataSource) throws Exception {
    	SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
    	sqlSessionFactory.setDataSource(dataSource);
    	sqlSessionFactory.setConfigLocation(new ClassPathResource(MYBATIS_CONFIG_LOCATION));
    	sqlSessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources(MYBATIS_MAPPER_LOCATION));
    	sqlSessionFactory.setVfs(SpringBootVFS.class);
    	return sqlSessionFactory.getObject();
	}

    @Primary
    @Bean
    SqlSessionTemplate firstSqlSessionTemplate(@Qualifier("firstSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
    	return new SqlSessionTemplate(sqlSessionFactory);
	}

}
```

- FirstTransactionAspect

```java
@Configuration
@Aspect
public class FirstTransactionAspect {

	private static final String AOP_TRANSACTION_EXPRESSION = "execution(* com.kdk.app.**..impl.*Impl.*(..))";

	@Qualifier("firstTransactionManager")
	@Autowired
	private TransactionManager firstTransactionManager;

	private static final String[] DEFAULT_READ_ONLY_METHOD_RULE_TRANSACTION_ATTRIBUTES = {
		"select*",
		"get*",
		"find*",
		"search*"
	};

	private static final String[] DEFAULT_REQUIRED_METHOD_RULE_TRANSACTION_ATTRIBUTES = {
		"*"
	};

	private RuleBasedTransactionAttribute readOnlyTransactionRule () {
		RuleBasedTransactionAttribute readOnly = new RuleBasedTransactionAttribute();
		readOnly.setReadOnly(true);
		readOnly.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		return readOnly;
	}

	private RuleBasedTransactionAttribute requiredTransactionRule () {
		RuleBasedTransactionAttribute required = new RuleBasedTransactionAttribute();
		required.setRollbackRules(Collections.singletonList(new RollbackRuleAttribute(Exception.class)));
		required.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		required.setTimeout(TransactionDefinition.TIMEOUT_DEFAULT);
		return required;
	}

    @Bean
    TransactionInterceptor firstTransactionAdvice() {
    	NameMatchTransactionAttributeSource transactionAttributeSource = new NameMatchTransactionAttributeSource();

    	RuleBasedTransactionAttribute readOnly = this.readOnlyTransactionRule();
    	RuleBasedTransactionAttribute required = this.requiredTransactionRule();

    	for (String methodName : DEFAULT_READ_ONLY_METHOD_RULE_TRANSACTION_ATTRIBUTES) {
    		transactionAttributeSource.addTransactionalMethod(methodName , readOnly);
    	}

    	for (String methodName : DEFAULT_REQUIRED_METHOD_RULE_TRANSACTION_ATTRIBUTES) {
    		transactionAttributeSource.addTransactionalMethod(methodName , required);
    	}

    	return new TransactionInterceptor(firstTransactionManager, transactionAttributeSource);
	}

    @Bean
    Advisor firstTransactionAdviceAdvisor() {
    	AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
    	pointcut.setExpression(AOP_TRANSACTION_EXPRESSION);

    	return new DefaultPointcutAdvisor(pointcut, this.firstTransactionAdvice());
	}

}
```

- SecondDataSourceConfig

```java
@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = {"com.kdk.app.mapper.second.**"}, annotationClass = Mapper.class, sqlSessionFactoryRef = "secondSqlSessionFactory")
public class SecondDataSourceConfig {

	private static final String MYBATIS_CONFIG_LOCATION = "mybatis/configuration.xml";
	private static final String MYBATIS_MAPPER_LOCATION = "classpath:mybatis/mappers/second/**/*.xml";

	@Bean
    @ConfigurationProperties(prefix = "spring.datasource.hikari")
    HikariConfig secondHikariConfig() {
		return new HikariConfig();
	}

    @Bean
    @ConfigurationProperties(prefix = "spring.second.datasource")
    DataSource secondDataSource() {
    	HikariDataSource secondDataSource = new HikariDataSource();

    	secondDataSource.setConnectionTimeout(this.secondHikariConfig().getConnectionTimeout());
    	secondDataSource.setMaxLifetime(this.secondHikariConfig().getMaxLifetime());
    	secondDataSource.setConnectionTestQuery(this.secondHikariConfig().getConnectionTestQuery());
    	secondDataSource.setValidationTimeout(this.secondHikariConfig().getValidationTimeout());
    	secondDataSource.setMaximumPoolSize(this.secondHikariConfig().getMaximumPoolSize());

    	return secondDataSource;
	}

    @Bean
    PlatformTransactionManager secondTransactionManager(@Qualifier("secondDataSource") DataSource dataSource) {
    	return new DataSourceTransactionManager(dataSource);
	}

    @Bean
    SqlSessionFactory secondSqlSessionFactory(@Qualifier("secondDataSource") DataSource dataSource) throws Exception {
    	SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
    	sqlSessionFactory.setDataSource(dataSource);
    	sqlSessionFactory.setConfigLocation(new ClassPathResource(MYBATIS_CONFIG_LOCATION));
    	sqlSessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources(MYBATIS_MAPPER_LOCATION));
    	sqlSessionFactory.setVfs(SpringBootVFS.class);
    	return sqlSessionFactory.getObject();
	}

    @Bean
    SqlSessionTemplate secondSqlSessionTemplate(@Qualifier("secondSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
    	return new SqlSessionTemplate(sqlSessionFactory);
	}

}
```

- SecondTransactionAspect

```java
@Configuration
@Aspect
public class SecondTransactionAspect {

	private static final String AOP_TRANSACTION_EXPRESSION = "execution(* com.lotteworld.app.**..impl.*Impl.*(..))";

	@Qualifier("secondTransactionManager")
	@Autowired
	private TransactionManager secondTransactionManager;

	private static final String[] DEFAULT_READ_ONLY_METHOD_RULE_TRANSACTION_ATTRIBUTES = {
		"select*",
		"get*",
		"find*",
		"search*"
	};

	private static final String[] DEFAULT_REQUIRED_METHOD_RULE_TRANSACTION_ATTRIBUTES = {
		"*"
	};

	private RuleBasedTransactionAttribute readOnlyTransactionRule () {
		RuleBasedTransactionAttribute readOnly = new RuleBasedTransactionAttribute();
		readOnly.setReadOnly(true);
		readOnly.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		return readOnly;
	}

	private RuleBasedTransactionAttribute requiredTransactionRule () {
		RuleBasedTransactionAttribute required = new RuleBasedTransactionAttribute();
		required.setRollbackRules(Collections.singletonList(new RollbackRuleAttribute(Exception.class)));
		required.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		required.setTimeout(TransactionDefinition.TIMEOUT_DEFAULT);
		return required;
	}

	@Bean
    TransactionInterceptor secondTransactionAdvice() {
		NameMatchTransactionAttributeSource transactionAttributeSource = new NameMatchTransactionAttributeSource();

		RuleBasedTransactionAttribute readOnly = this.readOnlyTransactionRule();
		RuleBasedTransactionAttribute required = this.requiredTransactionRule();

		for (String methodName : DEFAULT_READ_ONLY_METHOD_RULE_TRANSACTION_ATTRIBUTES) {
			transactionAttributeSource.addTransactionalMethod(methodName , readOnly);
		}

		for (String methodName : DEFAULT_REQUIRED_METHOD_RULE_TRANSACTION_ATTRIBUTES) {
			transactionAttributeSource.addTransactionalMethod(methodName , required);
		}

		return new TransactionInterceptor(secondTransactionManager, transactionAttributeSource);
	}

	@Bean
    Advisor secondTransactionAdviceAdvisor() {
		AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
		pointcut.setExpression(AOP_TRANSACTION_EXPRESSION);

		return new DefaultPointcutAdvisor(pointcut, this.secondTransactionAdvice());
	}

}
```