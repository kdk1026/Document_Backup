# PostgreSQL

```bash
#!/bin/bash

# -v ON_ERROR_STOP=1 : 에러 발생 시 즉시 중단 및 쉘에 실패 상태 코드 반환
# --single-transaction (-1) : 전체 스크립트를 하나의 트랜잭션(BEGIN~COMMIT)으로 자동 실행
psql -h hostname -U username -d database_name -v ON_ERROR_STOP=1 --single-transaction <<EOF
-- 수행할 DML 구문들 (명시적 BEGIN/COMMIT 생략 가능)

EOF

# 쉘에서 실행 결과 확인
if [ $? -ne 0 ]; then
    echo "SQL 실행 중 에러가 발생하여 자동 ROLLBACK 되었습니다."
    exit 1
else
    echo "SQL 실행 및 COMMIT 성공."
fi
```