# Oracle

```bash
#!/bin/bash

sqlplus -s username/password@db_connect_string <<EOF
-- 1. 에러 발생 시 즉시 ROLLBACK 후 실패(FAILURE) 상태로 종료
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

-- 2. Autocommit 비활성화 (기본값이 OFF이지만 명시)
SET AUTOCOMMIT OFF;

-- 3. 수행할 DML 구문들

-- 4. 모든 구문이 정상 완료되었을 때만 COMMIT
COMMIT;
EXIT 0;
EOF

# 쉘에서 SQL 실행 결과 확인 ($? 변수 이용)
if [ $? -ne 0 ]; then
    echo "SQL 실행 중 에러가 발생하여 ROLLBACK 처리되었습니다."
    exit 1
else
    echo "SQL 실행 및 COMMIT 성공."
fi
```