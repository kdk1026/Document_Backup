# React js파일에서 Redux 사용

```jsx
authAction.setIsLogin(store.dispatch, true);
```