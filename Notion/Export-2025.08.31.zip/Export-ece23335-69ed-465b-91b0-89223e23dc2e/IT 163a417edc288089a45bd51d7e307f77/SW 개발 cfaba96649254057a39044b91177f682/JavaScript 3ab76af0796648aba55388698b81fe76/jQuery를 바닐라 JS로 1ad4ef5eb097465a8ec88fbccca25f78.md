# jQuery를 바닐라 JS로

- https://whales.tistory.com/62
- jQuery load
    - [https://aosceno.tistory.com/567](https://aosceno.tistory.com/567)

[jQuery extend](jQuery%EB%A5%BC%20%EB%B0%94%EB%8B%90%EB%9D%BC%20JS%EB%A1%9C%201ad4ef5eb097465a8ec88fbccca25f78/jQuery%20extend%20337de1a002354481a378b965a3934b46.md)