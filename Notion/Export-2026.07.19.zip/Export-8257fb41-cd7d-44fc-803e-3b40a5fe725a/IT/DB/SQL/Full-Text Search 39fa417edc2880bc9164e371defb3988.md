# Full-Text Search

- `LIKE %검색어%` **FULL TABLE SCAN** 문제 해결

```sql
/* Oracle */
-- 인덱스 생성
CREATE INDEX idx_name ON
table_name(column_name) INDEXTYPE IS CTXSYS.CONTEXT;

-- 검색 수행
SELECT * FROM table_name
WHERE CONTAINS(column_name, '검색어') > 0;

/* MSSQL */
SELECT * FROM table_name
WHERE CONTAINS(column_name, '검색어');

/* MySQL */
SELECT * FROM table_name
WHERE MATCH(column_name) AGAINST('검색어' IN NATURAL LANGUAGE MODE);

/* PostgreSQL */
-- 특수문자 제한적, 영한 혼용 제한적 > pg_trgm 이 현실적인 대안
SELECT * FROM table_name
WHERE to_tsvector('korean', column_name) @@ websearch_to_tsquery('korean', '"검색어" -simple');

-- pg_trgm 확장 설치
CREATE EXTENSION IF NOT EXISTS pg_trgm; 

-- email 컬럼에 trigram 인덱스 생성
CREATE INDEX idx_users_email_trgm ON public.users
USING GIN (email gin_trgm_ops);

-- 조회
SELECT * FROM users
WHERE email like '%park04%';
```