# com.sun.crypto.provider.SunJCE 오류

- JVM argument를 설정해주어야 함
    - Eclipse
        - Run > Run Configurations > Arguments > VM arguments
        
        ```java
        --add-exports=java.base/com.sun.crypto.provider=ALL-UNNAMED
        ```
        
    - 실행
    
    ```bash
    java -jar -D --add-exports=java.base/com.sun.crypto.provider=ALL-UNNAMED $WAR_FILE_NM
    ```