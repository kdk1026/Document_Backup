# Cache 처리

- pom.xml

```jsx
<!-- 캐시 처리 -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-cache</artifactId>
        </dependency>
        <dependency>
            <groupId>com.github.ben-manes.caffeine</groupId>
            <artifactId>caffeine</artifactId>
        </dependency>
```

- application.properties

```jsx
spring.cache.type=caffeine
```

- CacheConfig

```jsx
@Configuration
@EnableCaching
public class CacheConfig {
    @Bean
		CacheManager cacheManager() {
		    CaffeineCacheManager cacheManager = new CaffeineCacheManager();
		    // 기본 캐시 설정
		    cacheManager.setCaffeine(Caffeine.newBuilder()
		            .expireAfterWrite(10, TimeUnit.MINUTES)
		            .maximumSize(200));
		
		    // 개별 캐시
		    cacheManager.registerCustomCache("customCache1", 
		        Caffeine.newBuilder()
		            .expireAfterWrite(5, TimeUnit.MINUTES)
		            .maximumSize(100)
		            .build());
		
		    cacheManager.registerCustomCache("customCache2", 
		        Caffeine.newBuilder()
		            .expireAfterWrite(15, TimeUnit.MINUTES)
		            .maximumSize(300)
		            .build());
		
		    return cacheManager;
		}
}
```

- Service

```jsx
// 키가 1개인 경우
@Cacheable(value = "lpointAuthInfoCache", key = "#acesTkn")
@Override
public AuthUserVo getAuthenticatedUser(String acesTkn) {

// 키가 n개인 경우
@Cacheable(value = "codeListCache", key = "#vo.codeWorkGrpId + '_' + #vo.codeGrpId")
@Override
public List<CodeVo> getCodeList(CodeParamVo vo) {
```