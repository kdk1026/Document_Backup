# Swagger (Spring Boot 2)

- pom.xml

```xml
<!-- https://mvnrepository.com/artifact/io.springfox/springfox-boot-starter -->
<dependency>
	<groupId>io.springfox</groupId>
	<artifactId>springfox-boot-starter</artifactId>
	<version>3.0.0</version>
</dependency>
```

- application.properties

```yaml
# Swagger
swagger.title=InfoAdmin Data API Docs
swagger.description=InfoAdmin Data API
swagger.version=v0.1

spring.mvc.pathmatch.matching-strategy=ant-path-matcher
```

- SwaggerProperties

```java
@Getter
@Setter
@ConfigurationProperties("swagger")
public class SwaggerProperties {

	private String title;
	private String description;
	private String version;

}
```

- SwaggerConfiguration

```java
@Configuration
@EnableSwagger2
public class SwaggerConfiguration {

	@Bean
	public SwaggerProperties swaggerProperties() {
		return new SwaggerProperties();
	}

	@Bean
	public Docket api(SwaggerProperties swaggerProperties) {
		final ApiInfo apiInfo = new ApiInfoBuilder()
				.version(swaggerProperties.getVersion())
				.title(swaggerProperties.getTitle())
				.description(swaggerProperties.getDescription())
				.build();

		return new Docket(DocumentationType.SWAGGER_2)
				.apiInfo(apiInfo)
				.select()
				.apis(RequestHandlerSelectors.basePackage("com.infoin.app"))
				.paths(PathSelectors.any())
				.build()
				.securityContexts( Arrays.asList(this.securityContext()) )
				.securitySchemes( Arrays.asList(this.apiKey()) );
	}

	private ApiKey apiKey() {
		return new ApiKey("Bearer accessToken", "Authorization", "header");
	}

	private SecurityContext securityContext() {
		return SecurityContext.builder().securityReferences(defaultAuth()).build();
	}

	private List<SecurityReference> defaultAuth() {
		AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
	    AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
	    authorizationScopes[0] = authorizationScope;
	    return Arrays.asList(new SecurityReference("Bearer accessToken", authorizationScopes));
	}

}
```

- SwaggerInterceptor

```java
public class SwaggerInterceptor extends LogDeclare implements HandlerInterceptor {

	private static final String PRIVATE_IP = "192.168.1";

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		String[] sAllowIps = {"127.0.0.1", "0:0:0:0:0:0:0:1", "175.209.116.226"};
		List<String> listAllowIp = Arrays.asList(sAllowIps);

		String sReqIp = RequestUtil.getRequestIpAddress(request);

		if ( !listAllowIp.contains(sReqIp) || sReqIp.startsWith(PRIVATE_IP) ) {
			CommonResVo commonResVo = new CommonResVo();
			commonResVo.setCode(ResponseCodeEnum.ERROR.getCode());
			commonResVo.setMessage("유효하지 않은 접근입니다.");

			String sJson = GsonUtil.ToJson.converterObjToJsonStr(commonResVo);

			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
			response.setCharacterEncoding(StandardCharsets.UTF_8.toString());
			response.getWriter().write(sJson);

			return false;
		}

		return true;
	}

}
```

- WebMvcConfig

```java
...

@Override
public void addInterceptors(InterceptorRegistry registry) {
	registry.addInterceptor( new SwaggerInterceptor() )
		.addPathPatterns("/swagger-ui/index.html");
}
```

- Controller 클래스

```java
@Api(tags = "find")
@Tag(name = "find", description = "찾기 API")
@RestController
@RequestMapping("/api/find")
public class FindUserController extends LogDeclare {
```

- Controller 메소드

```java
@Operation(summary = "아이디 찾기 처리")
@PostMapping("/userIdFind")
public CommonResVo userIdFind(@Valid FindUserParamVo findUserParamVo, BindingResult bindingResult) {
```

- Param VO 클래스

```java
@Getter
@Setter
@ToString
public class FindUserParamVo {

	@ApiModelProperty(required = true, value = "사용자 명칭")
	@NotBlank(message = "사용자 명칭은 필수 항목입니다.")
	private String userNm;
```

- Response VO 클래스

```java
@Getter
@Setter
@ToString
public class LoginResVo extends CommonResVo {

	@Schema(description = "토큰 타입", required = true)
	private String tokenType;
```

- Controller 메소드 인자

```java
public DiaryResVO getList(@Parameter(description = "다이어리 작성자 순번", required = true) @RequestParam String diaryWriterSn){

...

public CommonResVo modBlockedUsers(@Parameter(description = "차단 해제할 친구 순번들", required = true) @RequestBody List<String> friendUserSns){

...

public DoodleResVo searchDoodle(@Parameter(description = "낙서 순번") @PathVariable("doodleSn") String doodleSn) {
```