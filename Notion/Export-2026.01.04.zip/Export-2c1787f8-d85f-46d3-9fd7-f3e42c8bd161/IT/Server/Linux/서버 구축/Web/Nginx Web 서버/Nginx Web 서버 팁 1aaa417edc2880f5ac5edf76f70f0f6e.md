# Nginx Web 서버 팁

- Nginx Web 서버 보안 설정
    - [https://m.blog.naver.com/xers1/221848630175](https://m.blog.naver.com/xers1/221848630175)
    
    - 1번 해당 파일
    
    ```jsx
    sites-enabled/default
    ```
    
    - 1번 외에는, 다음 파일에 설정
        - Ubuntu의 경우, 5번 기본 설정되어 있음
        - 6번은 Default가 OFF
    
    ```jsx
    nginx.conf
    ```
    

[http로 접속하면 https로](Nginx%20Web%20%EC%84%9C%EB%B2%84%20%ED%8C%81/http%EB%A1%9C%20%EC%A0%91%EC%86%8D%ED%95%98%EB%A9%B4%20https%EB%A1%9C%20231a417edc2880eca35de10bd2c1624a.md)

[에러 방지](Nginx%20Web%20%EC%84%9C%EB%B2%84%20%ED%8C%81/%EC%97%90%EB%9F%AC%20%EB%B0%A9%EC%A7%80%201aaa417edc288033a3e0ddd0da6decbb.md)

[Server 정보 숨기기](Nginx%20Web%20%EC%84%9C%EB%B2%84%20%ED%8C%81/Server%20%EC%A0%95%EB%B3%B4%20%EC%88%A8%EA%B8%B0%EA%B8%B0%20218a417edc2880208686f7244cf55239.md)