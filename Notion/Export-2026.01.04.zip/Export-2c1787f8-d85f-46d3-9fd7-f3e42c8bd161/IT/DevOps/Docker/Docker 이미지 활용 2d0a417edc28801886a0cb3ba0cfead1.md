# Docker 이미지 활용

<aside>
💡

Docker 컨테이너

</aside>

[<CI/CD> Jenkins](Docker%20%EC%9D%B4%EB%AF%B8%EC%A7%80%20%ED%99%9C%EC%9A%A9/CI%20CD%20Jenkins%201f211ca79485434185f486c00dd796d6.md)

[DB](Docker%20%EC%9D%B4%EB%AF%B8%EC%A7%80%20%ED%99%9C%EC%9A%A9/DB%201a9a417edc288060a12ac4ddb78c9c04.md)

[Message Brocker](Docker%20%EC%9D%B4%EB%AF%B8%EC%A7%80%20%ED%99%9C%EC%9A%A9/Message%20Brocker%202d0a417edc2880749738cb32e5e103eb.md)