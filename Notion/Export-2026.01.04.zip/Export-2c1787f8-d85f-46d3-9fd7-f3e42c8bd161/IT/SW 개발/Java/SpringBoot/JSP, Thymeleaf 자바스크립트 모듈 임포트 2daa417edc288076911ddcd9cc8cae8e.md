# JSP, Thymeleaf 자바스크립트 모듈 임포트

# JSP

- `${pageContext.request.contextPath}/` 사용하여, 컨텍스트 루트 변경 대응

```jsx
<script type="importmap">
{
  "imports": {
    "utils/": "${pageContext.request.contextPath}/static/js/utils/"
  }
}
</script>

<script type="module">
	import { add } from 'utils/math.js';
</script>
```

# Thymeleaf

- 링크 식별자 `[[@{...}]]` 사용하여, 컨텍스트 루트 변경 대응

```jsx
<script type="importmap">
{
  "imports": {
    "utils/": "[[@{/js/utils/}]]"
  }
}
</script>

<script type="module">
	import { add } from 'utils/math.js';
</script>
```