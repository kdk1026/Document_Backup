# SessionStorage 에 없으면 조회

```jsx
  const lang = useSelector((state) => state.lang.lang);
  const localeData = useSelector((state) => state.locale.localeData);

  const [currentLang, setCurrentLang] = useState(lang);

  const { apiData: localeList, callApi: fetchLocaleList } = useApi(getLocaleList, ['adv-ui', lang], false);

  useEffect(() => {
    const storageLocaleData = sessionStorage.getItem(LOCALE_DATA_STORAGE_KEY);
    if ( storageLocaleData ) {
      localeAction.setLocaleData(dispatch, JSON.parse(storageLocaleData));
    } else {
      fetchLocaleList();
    }
  }, []);

  useEffect(() => {
    if ( lang !== currentLang ) {
      setCurrentLang(lang);
    }
  }, [lang, currentLang]);

  useEffect(() => {
    if ( lang !== currentLang ) {
      fetchLocaleList(['adv-ui', lang]);
    }
  }, [currentLang, lang]);

  useEffect(() => {
    if ( localeList && localeList.length > 0 ) {
      localeAction.setLocaleData(dispatch, localeList);
      sessionStorage.setItem(LOCALE_DATA_STORAGE_KEY, JSON.stringify(localeList));
    }
  }, [localeList]);

  useEffect(() => {
    const localeDataJson = sessionStorage.getItem(LOCALE_DATA_STORAGE_KEY);
    if ( !localeDataJson && !isEmptyArray(localeData) ) {
      sessionStorage.setItem(LOCALE_DATA_STORAGE_KEY, JSON.stringify(localeData));
    }
  }, [location]);
```