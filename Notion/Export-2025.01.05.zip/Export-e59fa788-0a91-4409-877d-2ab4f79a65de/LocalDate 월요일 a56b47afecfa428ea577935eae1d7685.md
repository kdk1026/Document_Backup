# LocalDate 월요일

```java
LocalDate today = LocalDate.now();

LocalDate previousOrSameMonday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
LocalDate nextOrSameMonday = today.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY));

System.out.println("오늘 날짜: " + today);
System.out.println("이전 또는 같은 월요일: " + previousOrSameMonday);
System.out.println("다음 또는 같은 월요일: " + nextOrSameMonday);
```