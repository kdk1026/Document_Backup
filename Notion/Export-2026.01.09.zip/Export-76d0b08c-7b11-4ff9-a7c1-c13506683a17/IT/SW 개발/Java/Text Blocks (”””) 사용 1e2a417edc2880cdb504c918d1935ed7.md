# Text Blocks (”””) 사용

- Java 15 이상

```jsx
String name = "대광";
String end = "!!";
String message = """
    안녕하세요, %s님!
    오늘도 좋은 하루 보내세요%s
    """.formatted(name, end);
System.out.println(message);
```