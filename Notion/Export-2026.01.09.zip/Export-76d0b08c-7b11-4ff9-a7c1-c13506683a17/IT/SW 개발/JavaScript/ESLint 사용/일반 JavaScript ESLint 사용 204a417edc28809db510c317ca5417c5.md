# 일반 JavaScript ESLint 사용

- 폴더 생성 후, 이동
    
    ```jsx
    npm init
    
    // ESLint 설치
    npm install eslint --save-dev
    
    // ESLint 초기화 및 설정 파일 생성
    npx eslint --init
    
    // ESLint 실행
    npx eslint [파일 또는 폴더 경로]
    
    // 외부 경로는 실행이 안되므로 파일을 복사해서 실행
    ```