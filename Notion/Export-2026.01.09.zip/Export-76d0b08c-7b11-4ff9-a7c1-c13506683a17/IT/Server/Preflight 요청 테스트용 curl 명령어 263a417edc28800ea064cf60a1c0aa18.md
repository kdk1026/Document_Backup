# Preflight 요청 테스트용 curl 명령어

```jsx
curl -X OPTIONS https://도메인/api/URI \
  -H "Origin: https://도메인" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: Content-Type"
```

- 브라우저가 다른 도메인으로 실제 요청을 보내기 전에, 서버에 허용 여부를 확인하기 위해 보내는 예비 요청

- 줄바꿈 처리를 위해 `Git Bash` 에서 수행

- 이상 없는 경우, 명령어 정상 종료
- 이상 있는 경우, 응답 (WAF 차단 등)