# Vite Vue

```bash
# JavaScript vue 템플릿 생성
npm create vite@latest vite-test -- --template vue

# TypeScript vue-ts 템플릿 생성
npm create vite@latest vite-test -- --template vue-ts
```

```bash
npm install
npm run dev
```