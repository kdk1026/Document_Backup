# Code Templates Comments 설정

- File > Settings > Editor > File and Code Templates
    - Includes > File Header
    
    ```jsx
    /**
     * <pre>
     * -----------------------------------
     * 개정이력
     * -----------------------------------
     * $DATE$ $USER$    최초작성
     * </pre>
     * 
     *
     * @author $USER$
     */
    ```