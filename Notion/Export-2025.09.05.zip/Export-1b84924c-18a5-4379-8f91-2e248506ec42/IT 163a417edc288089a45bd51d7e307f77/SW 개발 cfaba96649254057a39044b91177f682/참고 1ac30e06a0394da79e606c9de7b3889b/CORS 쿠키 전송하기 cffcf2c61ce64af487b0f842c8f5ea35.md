# CORS 쿠키 전송하기

- https://buly.kr/FAbT1z9