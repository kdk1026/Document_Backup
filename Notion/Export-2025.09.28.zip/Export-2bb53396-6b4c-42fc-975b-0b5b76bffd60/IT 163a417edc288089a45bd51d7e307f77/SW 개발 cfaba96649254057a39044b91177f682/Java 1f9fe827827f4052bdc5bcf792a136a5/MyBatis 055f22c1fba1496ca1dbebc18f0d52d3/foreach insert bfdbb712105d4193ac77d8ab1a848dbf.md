# foreach insert

### MySQL

[https://haenny.tistory.com/182](https://haenny.tistory.com/182)

Oracle

[https://haenny.tistory.com/21](https://haenny.tistory.com/21)

- DECLARE BEGIN 의 경우, INSERT, DELETE 에서도 사용 가능