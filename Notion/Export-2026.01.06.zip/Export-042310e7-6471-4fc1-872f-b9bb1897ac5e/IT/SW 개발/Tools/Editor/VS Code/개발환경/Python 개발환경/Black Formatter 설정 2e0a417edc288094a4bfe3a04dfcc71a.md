# Black Formatter 설정

1. `Ctrl + ,(콤마)`
2. `Default Formatter` 검색
3. `Default Formatter` 를 `Black Formatter` 로 설정
4. `Format on save` 검색
5. `Format on save` 체크하여 활성화