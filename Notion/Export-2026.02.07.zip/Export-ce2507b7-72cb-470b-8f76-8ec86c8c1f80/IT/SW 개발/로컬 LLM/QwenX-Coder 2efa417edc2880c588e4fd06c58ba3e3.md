# QwenX-Coder

- `Ollama` 설치

- 터미널을 통해 `모델 다운로드`
    - [https://ollama.com/library](https://ollama.com/library)

- 권장 (표준)
    - VRAM 24GB (RTX 3090/4090급) 또는 RAM 32GB 이상
    - 내장 그래픽 환경에 적합하지 않음
    
    ```jsx
    ollama run qwen3-coder:30b
    ```
    

- 경량 (속도 우선)
    - 약 4.7GB 정도의 메모리만 점유
    - 내장 그래픽 환경에 권장
    
    ```jsx
    ollama run qwen2.5-coder:7b
    ```
    

- Ollama 명령어
    
    ```jsx
    # 다운로드된 모델 목록 확인
    ollama list
    
    # 모델 삭제하기
    ollama rm 모델이름
    ```
    
- Ollama 앱에서 `qwen3-coder:480b-cloud` 선택하여 사용 가능

- VS Code 연동
    - `Continue` 확장 설치
    - Models 설정
        
        ```jsx
        name: Local Config
        version: 1.0.0
        schema: v1
        models:
          - name: Qwen2.5-Coder 1.5B
            provider: ollama
            model: qwen2.5-coder:1.5b-base
            roles:
              - autocomplete
          - name: Qwen 2.5 Coder 7b
            provider: ollama
            model: qwen2.5-coder:7b
            roles:
              - chat
              - edit
              - apply
              - autocomplete
        ```