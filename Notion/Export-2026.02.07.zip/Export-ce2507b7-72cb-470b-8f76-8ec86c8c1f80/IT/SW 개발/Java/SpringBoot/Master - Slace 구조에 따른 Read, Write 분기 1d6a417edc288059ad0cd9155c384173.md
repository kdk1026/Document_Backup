# Master - Slace 구조에 따른 Read, Write 분기

- (참고) [https://k3068.tistory.com/102](https://k3068.tistory.com/102)

- application.yml

```jsx
spring:
  hp:
    datasource:
      jndi-name: java:comp/env/jdbc/devhpdb
      password: ENC(jsvTFb59CcSPuVlYrOMQXcOMU8lZv4NL)
      username: ENC(ickTztmwqZjZZY9Qn3gfdGoS4dtwr9Qo)
  hp2:
    datasource:
      jndi-name: java:comp/env/jdbc/devhpdb_read
      password: ENC(jsvTFb59CcSPuVlYrOMQXcOMU8lZv4NL)
      username: ENC(ickTztmwqZjZZY9Qn3gfdGoS4dtwr9Qo)
  oi:
    datasource:
      jndi-name: java:comp/env/jdbc/devoidb
      password: ENC(MuVS3Eg1c4lbLAqB6i756IYqwMVjShby)
      username: ENC(UfQJ/olA1K428sN2K1FDQ6WFGfkG1MzK)
  oi2:
    datasource:
      jndi-name: java:comp/env/jdbc/devoidb_read
      password: ENC(MuVS3Eg1c4lbLAqB6i756IYqwMVjShby)
      username: ENC(UfQJ/olA1K428sN2K1FDQ6WFGfkG1MzK)
```

- DataSourceConfig

```jsx
@Slf4j
@Configuration
public class DataSourceConfig {

        @Value("${spring.hp.datasource.jndi-name}")
        String hpJndiName;

        @Value("${spring.hp2.datasource.jndi-name}")
        String hp2JndiName;

        @Value("${spring.oi.datasource.jndi-name}")
        String oiJndiName;

        @Value("${spring.oi2.datasource.jndi-name}")
        String oi2JndiName;

    @Bean
    DataSource masterHpDataSource() throws IllegalArgumentException, NamingException {
    	JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
        bean.setJndiName(hpJndiName);
        bean.setProxyInterface(DataSource.class);
        bean.setLookupOnStartup(false);
        bean.afterPropertiesSet();
        return (DataSource) bean.getObject();
        }

    @Bean
    DataSource slaveHpDataSource() throws IllegalArgumentException, NamingException {
    	JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
    	bean.setJndiName(hp2JndiName);
    	bean.setProxyInterface(DataSource.class);
    	bean.setLookupOnStartup(false);
    	bean.afterPropertiesSet();
    	return (DataSource) bean.getObject();
    }

    @Bean
    DataSource masterOiDataSource() throws IllegalArgumentException, NamingException {
    	try {
			JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
			bean.setJndiName(oiJndiName);
			bean.setProxyInterface(DataSource.class);
			bean.setLookupOnStartup(false);
			bean.afterPropertiesSet();
			return (DataSource) bean.getObject();
			
		} catch (NamingException e) {
			log.error("masterOiDataSource 연결 실패 : {}", e);
			return null;
		} catch (Exception e) {
			log.error("masterOiDataSource 연결 실패 : {}", e);
			return null;
		}
    }

    @Bean
    DataSource slaveOiDataSource() throws IllegalArgumentException, NamingException {
    	try {
			JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
			bean.setJndiName(oi2JndiName);
			bean.setProxyInterface(DataSource.class);
			bean.setLookupOnStartup(false);
			bean.afterPropertiesSet();
			return (DataSource) bean.getObject();
			
		} catch (NamingException e) {
			log.error("slaveOiDataSource 연결 실패 : {}", e);
			return null;
		} catch (Exception e) {
			log.error("slaveOiDataSource 연결 실패 : {}", e);
			return null;
		}
    }

}
```

- RoutingDataSource

```jsx
public class RoutingDataSource extends AbstractRoutingDataSource {

	public RoutingDataSource(Map<Object, Object> datasourceMap, Object defaultTarget) {
        setTargetDataSources(datasourceMap);
        setDefaultTargetDataSource(defaultTarget);
        afterPropertiesSet();
    }

	@Override
	protected Object determineCurrentLookupKey() {
		return TransactionSynchronizationManager.isCurrentTransactionReadOnly() ? "slave" : "master";
	}

}
```

- HpDataSourceConfig

```jsx
@Configuration
public class HpDataSourceConfig {

	public static final String MASTER_DATASOURCE = "masterHpDataSource";
    public static final String SLAVE_DATASOURCE = "slaveHpDataSource";

	@Bean
	@Primary
	@DependsOn({MASTER_DATASOURCE, SLAVE_DATASOURCE})
	DataSource hpRoutingDataSource(
		@Qualifier(MASTER_DATASOURCE) DataSource masterHpDataSource,
		@Qualifier(SLAVE_DATASOURCE) DataSource slaveHpDataSource) {

		Map<Object, Object> datasourceMap = new HashMap<>();
		if (masterHpDataSource != null) datasourceMap.put("master", masterHpDataSource);
		if (slaveHpDataSource != null) datasourceMap.put("slave", slaveHpDataSource);

		return new RoutingDataSource(datasourceMap, masterHpDataSource);
	}
}
```

- OiDataSourceConfig

```jsx
@Configuration
public class OiDataSourceConfig {

	public static final String MASTER_DATASOURCE = "masterOiDataSource";
    public static final String SLAVE_DATASOURCE = "slaveOiDataSource";

	@Bean
	DataSource oiRoutingDataSource(
		@Qualifier(MASTER_DATASOURCE) DataSource masterOiDataSource,
		@Qualifier(SLAVE_DATASOURCE) DataSource slaveOiDataSource) {
			
		Map<Object, Object> datasourceMap = new HashMap<>();
		if (masterOiDataSource != null) datasourceMap.put("master", masterOiDataSource);
		if (slaveOiDataSource != null) datasourceMap.put("slave", slaveOiDataSource);

		if ( datasourceMap.isEmpty() ) {
			return null;
		}

	    return new RoutingDataSource(datasourceMap, masterOiDataSource);
	}

}
```

- ProxyDatasource

```jsx
@Configuration
public class ProxyDatasource {

	@Bean
	@DependsOn("hpRoutingDataSource")
	LazyConnectionDataSourceProxy hpDataSource(@Qualifier("hpRoutingDataSource") DataSource hpRoutingDataSource) {
			return new LazyConnectionDataSourceProxy(hpRoutingDataSource);
	}

	@Bean
	@ConditionalOnBean(name = "oiRoutingDataSource")
	LazyConnectionDataSourceProxy oiDataSource(@Qualifier("oiRoutingDataSource") DataSource oiRoutingDataSource) {
			return new LazyConnectionDataSourceProxy(oiRoutingDataSource);
	}

}
```

- TransactionConfig

```jsx
@Configuration
public class TransactionConfig {

	@Primary
    @Bean
    PlatformTransactionManager hpTransactionManager(@Qualifier("hpDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
	}

    @Bean
	@ConditionalOnBean(name = "oiDataSource")
    PlatformTransactionManager oiTransactionManager(@Qualifier("oiDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
	}

}
```

- OiTransactionAspect

```jsx
@Configuration
@Aspect
public class OiTransactionAspect {

	private static final String AOP_TRANSACTION_EXPRESSION = "execution(* com.lotteworld.app.**.**..impl.*Impl.*(..))";

	@Qualifier("oiTransactionManager")
	@Autowired
	private TransactionManager oiTransactionManager;

	private static final String[] DEFAULT_READ_ONLY_METHOD_RULE_TRANSACTION_ATTRIBUTES = {
		"select*",
		"get*",
		"find*",
		"search*"
	};

	private static final String[] DEFAULT_REQUIRED_METHOD_RULE_TRANSACTION_ATTRIBUTES = {
		"*"
	};

	private RuleBasedTransactionAttribute readOnlyTransactionRule () {
		RuleBasedTransactionAttribute readOnly = new RuleBasedTransactionAttribute();
		readOnly.setReadOnly(true);
		readOnly.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		return readOnly;
	}

	private RuleBasedTransactionAttribute requiredTransactionRule () {
		RuleBasedTransactionAttribute required = new RuleBasedTransactionAttribute();
		required.setRollbackRules(Collections.singletonList(new RollbackRuleAttribute(Exception.class)));
		required.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		required.setTimeout(TransactionDefinition.TIMEOUT_DEFAULT);
		return required;
	}

	@Bean
	@ConditionalOnBean(name = "oiTransactionManager")
    TransactionInterceptor oiTransactionAdvice() {
		NameMatchTransactionAttributeSource transactionAttributeSource = new NameMatchTransactionAttributeSource();

		RuleBasedTransactionAttribute readOnly = this.readOnlyTransactionRule();
		RuleBasedTransactionAttribute required = this.requiredTransactionRule();

		for (String methodName : DEFAULT_READ_ONLY_METHOD_RULE_TRANSACTION_ATTRIBUTES) {
			transactionAttributeSource.addTransactionalMethod(methodName , readOnly);
		}

		for (String methodName : DEFAULT_REQUIRED_METHOD_RULE_TRANSACTION_ATTRIBUTES) {
			transactionAttributeSource.addTransactionalMethod(methodName , required);
		}

		return new TransactionInterceptor(oiTransactionManager, transactionAttributeSource);
	}

	@Bean
	@ConditionalOnBean(name = "oiTransactionAdvice")
    Advisor oiTransactionAdviceAdvisor() {
		AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
		pointcut.setExpression(AOP_TRANSACTION_EXPRESSION);

		return new DefaultPointcutAdvisor(pointcut, this.oiTransactionAdvice());
	}

}
```

- HpMyBatisConfig

```jsx
@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = {"com.lotteworld.app.mapper.hp.**"}, annotationClass = Mapper.class, sqlSessionFactoryRef = "hpSqlSessionFactory")
public class HpMyBatisConfig {

        private static final String MYBATIS_CONFIG_LOCATION = "mybatis/mybatis-config.xml";
        private static final String MYBATIS_MAPPER_LOCATION = "classpath:mybatis/mappers/hp/**/*.xml";

        @Primary
    @Bean
    SqlSessionFactory hpSqlSessionFactory(@Qualifier("hpDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
        sqlSessionFactory.setDataSource(dataSource);
        sqlSessionFactory.setConfigLocation(new ClassPathResource(MYBATIS_CONFIG_LOCATION));
        sqlSessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources(MYBATIS_MAPPER_LOCATION));
        sqlSessionFactory.setVfs(SpringBootVFS.class);
        return sqlSessionFactory.getObject();
        }

    @Primary
    @Bean
    SqlSessionTemplate hpSqlSessionTemplate(@Qualifier("hpSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
        }

}
```

- OiMyBatisConfig

```jsx
@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = {"com.lotteworld.app.mapper.oi.**"}, annotationClass = Mapper.class, sqlSessionFactoryRef = "oiSqlSessionFactory")
public class OiMyBatisConfig {

        private static final String MYBATIS_CONFIG_LOCATION = "mybatis/mybatis-config.xml";
        private static final String MYBATIS_MAPPER_LOCATION = "classpath:mybatis/mappers/oi/**/*.xml";

    @Bean
    SqlSessionFactory oiSqlSessionFactory(@Qualifier("oiDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
        sqlSessionFactory.setDataSource(dataSource);
        sqlSessionFactory.setConfigLocation(new ClassPathResource(MYBATIS_CONFIG_LOCATION));
        sqlSessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources(MYBATIS_MAPPER_LOCATION));
        sqlSessionFactory.setVfs(SpringBootVFS.class);
        return sqlSessionFactory.getObject();
        }

    @Bean
    SqlSessionTemplate oiSqlSessionTemplate(@Qualifier("oiSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
        }

}
```

- 로컬 TomcatEmbdded 설정
    
    [DataSource JNDI](DataSource%20JNDI%20a8626186a16742088667d1dd1e565571.md)
    
    ```jsx
    @Slf4j
    @Profile("local")
    @Configuration
    public class TomcatEmbdded {
    
    	private static final String TYPE = DataSource.class.getName();
    	private static final String AUTH = "Container";
    	//private static final String DRIVER_CLASS_NAME = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    	private static final String DRIVER_CLASS_NAME = "net.sf.log4jdbc.sql.jdbcapi.DriverSpy";
    	private static final String FACTORY = "org.apache.commons.dbcp2.BasicDataSourceFactory";
    
    	@Value("${tomcat.ajp.protocol}")
        String ajpProtocol;
    
        @Value("${tomcat.ajp.port}")
        int ajpPort;
    
    	@Value("${tomcat.ajp.host}")
    	String ajpHost;
    
    	@Value("${spring.first.datasource.url}")
        String firstUrl;
    
    	@Value("${spring.first.datasource.password}")
        String firstPassword;
    
    	@Value("${spring.first.datasource.username}")
    	String firstUsername;
    
    	@Value("${spring.fourth.datasource.url}")
        String fourthUrl;
    
    	@Value("${spring.fourth.datasource.password}")
    	String fourthPassword;
    
    	@Value("${spring.fourth.datasource.username}")
    	String fourthUsername;
    
    	@Bean
    	TomcatServletWebServerFactory tomcatFactory() {
    		TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory() {
    			@Override
    			protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
    				tomcat.enableNaming();
    				return super.getTomcatWebServer(tomcat);
    			}
    
    			@Override
    			protected void postProcessContext(Context context) {
    				// 홈페이지 DB
    				ContextResource resource1w = new ContextResource();
    				resource1w.setName("jdbc/devhpdb");
    				resource1w.setType(TYPE);
    				resource1w.setAuth(AUTH);
    				resource1w.setProperty("driverClassName", DRIVER_CLASS_NAME);
    				resource1w.setProperty("url", firstUrl);
    				resource1w.setProperty("username", firstUsername);
    				resource1w.setProperty("password", firstPassword);
    				resource1w.setProperty("factory", FACTORY);
    
                    // 홈페이지 DB
                    ContextResource resource1r = new ContextResource();
                    resource1r.setName("jdbc/devhpdb_read");
                    resource1r.setType(TYPE);
                    resource1r.setAuth(AUTH);
                    resource1r.setProperty("driverClassName", DRIVER_CLASS_NAME);
                    resource1r.setProperty("url", firstUrl);
                    resource1r.setProperty("username", firstUsername);
                    resource1r.setProperty("password", firstPassword);
                    resource1r.setProperty("factory", FACTORY);
    
                    // 온라인통합 DB
                    ContextResource resource4w = new ContextResource();
                    resource4w.setName("jdbc/devoidb");
                    resource4w.setType(TYPE);
                    resource4w.setAuth(AUTH);
                    resource4w.setProperty("driverClassName", DRIVER_CLASS_NAME);
                    resource4w.setProperty("url", fourthUrl);
                    resource4w.setProperty("username", fourthUsername);
                    resource4w.setProperty("password", fourthPassword);
                    resource4w.setProperty("factory", FACTORY);
                    resource4w.setProperty("testWhileIdle", "false");
                    resource4w.setProperty("validationQuery", "");
    
                    // 온라인통합 DB
                    ContextResource resource4r = new ContextResource();
                    resource4r.setName("jdbc/devoidb_read");
                    resource4r.setType(TYPE);
                    resource4r.setAuth(AUTH);
                    resource4r.setProperty("driverClassName", DRIVER_CLASS_NAME);
                    resource4r.setProperty("url", fourthUrl);
                    resource4r.setProperty("username", fourthUsername);
                    resource4r.setProperty("password", fourthPassword);
                    resource4r.setProperty("factory", FACTORY);
                    resource4r.setProperty("testWhileIdle", "false");
                    resource4r.setProperty("validationQuery", "");
    
                    context.getNamingResources().addResource(resource1w);
                    context.getNamingResources().addResource(resource1r);
    
                    if ( isDbAlice(fourthUrl, fourthUsername, fourthPassword) ) {
                    	context.getNamingResources().addResource(resource4w);
                    }
                    if ( isDbAlice(fourthUrl, fourthUsername, fourthPassword) ) {
                    	context.getNamingResources().addResource(resource4r);
                    }
    
    			}
    		};
    
    		tomcat.addAdditionalTomcatConnectors(createAjpConnector());
    
    		return tomcat;
    	}
    
    	private Connector createAjpConnector() {
    		Connector ajpConnector = new Connector(ajpProtocol);
            ajpConnector.setPort(ajpPort);
            ajpConnector.setSecure(false);
            ajpConnector.setAllowTrace(false);
            ajpConnector.setScheme("http");
            ajpConnector.setProperty("address", ajpHost);
            ((AbstractAjpProtocol<?>)ajpConnector.getProtocolHandler()).setSecretRequired(false);
            return ajpConnector;
    	}
    
    	private boolean isDbAlice(String jdbcUrl, String username, String password) {
    		String timeJdbcUrl = jdbcUrl + ";loginTimeout=3;socketTimeout=3000;";
    
    	    try (Connection conn = DriverManager.getConnection(timeJdbcUrl, username, password)) {
    	        return conn != null && !conn.isClosed();
    	    } catch (SQLException e) {
    	    	log.error("Fourth DB 연결 실패: {}", e.getMessage());
    	        return false;
    	    }
    	}
    
    }
    
    ```