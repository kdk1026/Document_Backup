# Black Formatter 설정

1. `Ctrl + ,(콤마)`
2. `Default Formatter` 검색
3. `Default Formatter` 를 `Black Formatter` 로 설정
4. `Format on save` 검색, 체크하여 활성화
    1. **파이썬이 아닌 경우도 처리하므로 미체크 유지 권장**
    2. **특정 프로젝트에만 설정** (`.vscode/settings.json`)
    
    ```jsx
    {
        "editor.defaultFormatter": "ms-python.black-formatter",
        "editor.formatOnSave": true,
        "black-formatter.args": ["--line-length", "88"]
    }
    ```