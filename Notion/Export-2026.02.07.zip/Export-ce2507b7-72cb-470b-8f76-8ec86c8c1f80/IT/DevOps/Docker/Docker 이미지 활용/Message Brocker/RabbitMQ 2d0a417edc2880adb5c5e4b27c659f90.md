# RabbitMQ

- 이미지 받기

```bash
docker pull rabbitmq:management
```

- 이미지 확인

```bash
docker images
```

- 컨테이너 실행

```bash
docker run -d --name [CONTAINER_NAME] \
  -p 5672:5672 -p 15672:15672 \
  -e RABBITMQ_DEFAULT_USER=admin \
  -e RABBITMQ_DEFAULT_PASS=password \
  rabbitmq:management
```

- 관리자 페이지 접속 확인
    - **URL:** [`http://localhost:15672`](http://localhost:15672/)
    - **ID/PW**: 위에 설정한 admin / password