# AI 사이트

- [https://lmarena.ai/ko](https://lmarena.ai/ko)
    - AI 모델별 비교 테스트
    
- [https://chat.qwen.ai/](https://chat.qwen.ai/)
    - 중국 알리바바의 오픈소스 AI