# AI Agent Framework Python 버전

| 구분 | 버전 요구사항 |
| --- | --- |
| LangChain & LangGraph | [https://pypi.org/project/langchain/](https://pypi.org/project/langchain/)
[https://pypi.org/project/langgraph/](https://pypi.org/project/langgraph/) |