# MyBatis

[foreach insert, delete, update](MyBatis/foreach%20insert,%20delete,%20update%20bfdbb712105d4193ac77d8ab1a848dbf.md)

[foreach insert 분할 호출](MyBatis/foreach%20insert%20%EB%B6%84%ED%95%A0%20%ED%98%B8%EC%B6%9C%203b9a417edc2880e793f4dd9b58897a21.md)