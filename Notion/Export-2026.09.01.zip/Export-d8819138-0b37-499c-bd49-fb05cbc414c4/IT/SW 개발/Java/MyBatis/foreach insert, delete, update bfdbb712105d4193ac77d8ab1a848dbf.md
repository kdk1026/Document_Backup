# foreach insert, delete, update

[MySQL](foreach%20insert,%20delete,%20update/MySQL%203b9a417edc2880898616c7dc59103839.md)

[Oracle](foreach%20insert,%20delete,%20update/Oracle%203b9a417edc2880309819ce6436a0908f.md)

[MS SQL](foreach%20insert,%20delete,%20update/MS%20SQL%203b9a417edc2880d5947ec2fcbe995254.md)

[PostgreSQL](foreach%20insert,%20delete,%20update/PostgreSQL%203b9a417edc28803aa1bdc18d7d5b8dfe.md)