# PostgreSQL

```xml
<insert id="insertUserList" parameterType="java.util.List">
    INSERT INTO tb_user (
        user_name,
        email,
        created_at
    ) VALUES
    <foreach collection="list" item="item" separator=",">
        (
            #{item.userName},
            #{item.email},
            CURRENT_TIMESTAMP
        )
    </foreach>
</insert>
```

```xml
<delete id="deleteUsers" parameterType="java.util.List">
    DELETE FROM tb_user
    WHERE id IN
    <foreach collection="list" item="id" open="(" separator="," close=")">
        #{id}
    </foreach>
</delete>
```

```xml
<update id="updateUserList" parameterType="java.util.List">
    UPDATE tb_user AS u
    SET
        user_name = v.user_name,
        email = v.email,
        updated_at = CURRENT_TIMESTAMP
    FROM (VALUES
        <foreach collection="list" item="item" separator=",">
            (
                #{item.id}::bigint,
                #{item.userName},
                #{item.email}
            )
        </foreach>
    ) AS v(id, user_name, email)
    WHERE u.id = v.id
</update>
```

```xml
<update id="updateUserListMulti" parameterType="java.util.List">
    <foreach collection="list" item="item" separator=";">
        UPDATE tb_user
        SET
            user_name = #{item.userName},
            email = #{item.email}
        WHERE id = #{item.id}
    </foreach>
</update>
```