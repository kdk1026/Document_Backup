# foreach insert 분할 호출

- 성능상 500개로 분할 권장
    - MS SQL은 1,000개 제한 있으므로 필수

```java
public void saveBulkUsers(List<UserVO> allUsers) {
    int batchSize = 500;
    for (int i = 0; i < allUsers.size(); i += batchSize) {
        int end = Math.min(i + batchSize, allUsers.size());
        List<UserVO> subList = allUsers.subList(i, end);
        userMapper.insertUsers(subList);
    }
}
```