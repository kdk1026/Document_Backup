# Nginx root 설정 예시

- /etc/nginx/conf.d/was.conf

```jsx
server {
    listen 80;

    root /home/ubuntu/fo_front;
    index index.html;

    server_name live-infoin-skstoa.infoin-dev.com;

    location / {
        try_files $uri $uri/ /index.html;
        add_header Cache-Control "no-cache";
        expires -1;
    }
}
```