# JSP에서 JavaScript 템플릿 문자열 사용

```jsx
var today = '2023-07-25';
var msg = `오늘은 ${ "${today}" } 입니다.`; // 오늘은 2023-07-25 입니다.

const name = '커피';
console.log(`name : \{name}`);
```