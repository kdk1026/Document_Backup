# IntelliJ

- lombok 설치

- vmoptions 수정

```jsx
#---------------------------------------------
# JVM Heap의 최초/최대 크기 (동일하게 설정 권장)
#--------------------------------------------
-Xms4g
-Xmx4g
```

- vmoptions 추가

```jsx
# 인코딩 설정
-Dfile.encoding=UTF-8
# IPv6 보다 IPv4 우선 인식
-Djava.net.preferIPv4Stack=true
# 클래스 유효성 검사 생략
-Xverify:none
# 컴파일러의 소수점 최적화 기능 작동
-XX:+AggressiveOpts
```

[플러그인 설치](IntelliJ%2017ba417edc2880a297e7ef7a2c6d9dfa/%E1%84%91%E1%85%B3%E1%86%AF%E1%84%85%E1%85%A5%E1%84%80%E1%85%B3%E1%84%8B%E1%85%B5%E1%86%AB%20%E1%84%89%E1%85%A5%E1%86%AF%E1%84%8E%E1%85%B5%2017ba417edc288047a0bbd1ec62c8775e.md)

[팁](IntelliJ%2017ba417edc2880a297e7ef7a2c6d9dfa/%E1%84%90%E1%85%B5%E1%86%B8%201a6a417edc2880d9a86bf12792771750.md)