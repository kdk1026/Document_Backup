# axios Param 예제

```jsx
export const authLogin = (userId, userPw) => {
    return instance.post('/test/login', { userId, userPw });
};
```