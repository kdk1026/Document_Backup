# JBCrypt

- pom.xml

```xml
<!-- https://mvnrepository.com/artifact/org.mindrot/jbcrypt -->
<dependency>
	<groupId>org.mindrot</groupId>
	<artifactId>jbcrypt</artifactId>
	<version>0.4</version>
</dependency>
```

- BcryptTest

```java
public static void main(String[] args) {
	String sPlanText = "qwer1234";
	String sHashText = BCrypt.hashpw(sPlanText, BCrypt.gensalt());

	System.out.println(sHashText);

	boolean isCheck = BCrypt.checkpw(sPlanText, sHashText);
	System.out.println(isCheck);
}
```