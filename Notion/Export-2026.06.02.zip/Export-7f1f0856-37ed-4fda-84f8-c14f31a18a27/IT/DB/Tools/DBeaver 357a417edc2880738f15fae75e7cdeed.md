# DBeaver

<aside>
💡

플러그인 설치

- 도움말 > Install New Software
</aside>

<aside>
💡

추천 플러그인

- Darkest Dark Theme
    - DevStyle Features
        - DevStyle (includes Darkest Dark Theme)
        
- DBeaver Office integration
    - Excel, CSV 형식으로 내보내기
</aside>