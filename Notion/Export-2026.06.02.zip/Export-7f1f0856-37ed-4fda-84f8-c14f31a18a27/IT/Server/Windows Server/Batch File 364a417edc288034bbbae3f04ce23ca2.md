# Batch File

- Server가 아니어도 작성 가능하지만 주로 Server에서 사용

[출력, 변수, 입력, 주석](Batch%20File/%EC%B6%9C%EB%A0%A5,%20%EB%B3%80%EC%88%98,%20%EC%9E%85%EB%A0%A5,%20%EC%A3%BC%EC%84%9D%20364a417edc2880cfa20bc565ffba483a.md)

[조건 연산자/조건, 배열](Batch%20File/%EC%A1%B0%EA%B1%B4%20%EC%97%B0%EC%82%B0%EC%9E%90%20%EC%A1%B0%EA%B1%B4,%20%EB%B0%B0%EC%97%B4%20364a417edc28800b8d9fe801ee19a5de.md)

[조건문, 반복문](Batch%20File/%EC%A1%B0%EA%B1%B4%EB%AC%B8,%20%EB%B0%98%EB%B3%B5%EB%AC%B8%20364a417edc2880dc9231c99461620794.md)

[참고](Batch%20File/%EC%B0%B8%EA%B3%A0%20364a417edc2880fb9f4fef0da5b053e5.md)