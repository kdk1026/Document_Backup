# Shell Script 예제

- shutdown.sh

```bash
#!/bin/bash

## Edit By Project
WAR_FILE_NM=DongaSH-0.1.war
PROFILE=dev

## Rest Fixed
pid=$(ps -ef | grep -v grep | grep $WAR_FILE_NM | grep $PROFILE | awk '{print $2}')

if [ -n "$pid" ]; then
    echo "Sending SIGTERM to process $pid"
    kill -15 $pid

    timeout=30
    while [ $timeout -gt 0 ]; do
        if ! ps -p $pid > /dev/null; then
            echo "Process $pid terminated successfully"
            break
        fi
        sleep 1
        timeout=$((timeout - 1))
    done

    if [ $timeout -eq 0 ]; then
        echo "Process $pid did not terminate within the timeout period, sending SIGKILL"
        kill -9 $pid
    fi
else
    echo "PID is empty"
fi

```

- start.sh

```bash
#!/bin/bash

## Fix By Server
HOME_DIR=/home/webdev

## Edit By Project
WAR_DIR_NM=DongaSH
WAR_FILE_NM=DongaSH-0.1.war

## Fix
WAR_DIR=$HOME_DIR/$WAR_DIR_NM

## Rest Fixed
echo "########## Move WAR_DIR ##########"
cd "$WAR_DIR"

echo "========== Run shutdown.sh =========="
./shutdown.sh

echo "########## java -jar Run ##########"
#java -jar $WAR_FILE_NM --spring.profiles.active=dev &
nohup java -jar $WAR_FILE_NM --spring.profiles.active=dev > /dev/null 2>&1 &
```

- tomcat_log_clear.sh

```bash
#!/bin/bash

ARR=( `find ~/ -name 'tomcat9_*' -type d 2> /dev/null` )
#echo ${ARR[*]}

for i in ${ARR[*]}; do
  #echo $i
  #find $i -name '*.log' 2> /dev/null -ctime +1 -exec ls {} \;

  find $i -name '*.log' 2> /dev/null -ctime +30 -exec rm -f {} \;
  find $i -name '*.txt' 2> /dev/null -ctime +30 -exec rm -f {} \;
  /dev/null > $i/logs/catalina.out
done
```