# Nginx SSL 설정 예시

```jsx
server {
        listen 443 ssl;
        server_name svcmgmt.donga.co.kr;

        location / {
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;

                proxy_pass http://10.100.1.4:8080;
                proxy_redirect off;
                charset utf-8;
        }

        ssl_certificate /etc/nginx/ssl/svcmgmt.donga.co.kr/nginx_ssl.crt;
        ssl_certificate_key /etc/nginx/ssl/svcmgmt.donga.co.kr/nginx_ssl.key;

        ssl_session_cache shared:SSL:1m;
        ssl_session_timeout 5m;

        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:MEDIUM:!SSLv2:!PSK:!SRP:!ADH:!AECDH;
        ssl_prefer_server_ciphers on;

        access_log /var/log/nginx/svcmgmt.donga.co.kr/access.log combined;
        error_log /var/log/nginx/svcmgmt.donga.co.kr/error.log warn;
}
```