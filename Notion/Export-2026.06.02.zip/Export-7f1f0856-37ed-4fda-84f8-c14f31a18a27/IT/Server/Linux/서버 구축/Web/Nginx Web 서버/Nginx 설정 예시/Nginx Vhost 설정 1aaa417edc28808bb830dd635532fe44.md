# Nginx Vhost 설정

```jsx
server {
        listen 80;
        server_name bo-dev.bbangga.com;

        location / {
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;

                proxy_pass http://127.0.0.1:8080;
                proxy_redirect off;
                charset utf-8;
        }
}

server {
        listen 80;
        server_name api-dev.bbangga.com;

        location / {
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;

                proxy_pass http://127.0.0.1:8090;
                proxy_redirect off;
                charset utf-8;
        }
}

server {
        listen 80;
        server_name www-dev.bbangga.com;

        location / {
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;

                proxy_pass http://127.0.0.1:8100;
                proxy_redirect off;
                charset utf-8;
        }
}
```

- 클라이언트에 노출하지 않고, 요청에 임의의 헤더 추가

```jsx
server {
        listen 80;
        server_name api-dev.bbangga.com;

        location / {
				        proxy_set_header My-Secret-Header "Internal-Key";
				        
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;

                proxy_pass http://127.0.0.1:8090;
                proxy_redirect off;
                charset utf-8;
        }
}
```