# unescape

```jsx
// 이 외 추가
const regex = /&(quot|amp|lt|gt|#39);/g;
const chars = {
    '&quot;': '"',
    '&amp;': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&#39;': "'",
}
export const unescapeHtml = (str) => {
    if ( regex.test(str) ) {
        return str.replace(regex, (matched) => chars[matched] || matched);
    }
};
```

<aside>
💡 [https://buly.kr/AlipToT](https://buly.kr/AlipToT)

- html-entities 설치
</aside>