# React @ Alias

- vite.config.js

```jsx
/* eslint-disable no-undef */
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path';

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: [
      {
        find: '@',
        replacement: path.resolve(__dirname, 'src')
      }
    ]
  }
})
```

- jsconfig.json

```jsx
{
    "compilerOptions": {
        "baseUrl": ".",
        "paths": {
            "@/*": ["./src/*"],
        },
        "jsx": "react"
    },
    "include": ["src"],
    "exclude": ["node_modules", "dist"]
}
```