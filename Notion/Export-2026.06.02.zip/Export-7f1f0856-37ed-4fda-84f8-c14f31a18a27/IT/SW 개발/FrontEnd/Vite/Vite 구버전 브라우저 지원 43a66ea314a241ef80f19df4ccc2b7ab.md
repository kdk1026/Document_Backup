# Vite 구버전 브라우저 지원

- @vitejs/plugin-legacy 설치

```bash
npm install @vitejs/plugin-legacy
```

- vite.config.js

```bash
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import legacy from '@vitejs/plugin-legacy';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    legacy({
      targets: ['chrome >= 64', 'edge >= 79', 'safari >= 11.1', 'firefox >= 67'],
      modernPolyfills: true
    }),
  ],
  server: {
    host: '0.0.0.0'
  }
})
```