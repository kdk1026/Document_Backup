# vanillajs-datepicker

```jsx
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.jsdelivr.net/npm/vanillajs-datepicker@1.3.4/dist/js/datepicker-full.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vanillajs-datepicker@1.3.4/dist/js/locales/ko.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/vanillajs-datepicker@1.3.4/dist/css/datepicker.min.css" rel="stylesheet">
</head>
<body>
    
    <style>
        .datepicker .days-of-week .dow:first-child {
            color: #ff4d4f;
        }

        .datepicker .days-of-week .dow:last-child {
            color: #1890ff;
        }

        .datepicker .datepicker-grid .sunday {
            color: #ff4d4f;
        }

        .datepicker .datepicker-grid .saturday {
            color: #1890ff;
        }
    </style>
    
    <div>
        <input type="text" id="datepicker" />
    </div>

    <script>
        const elem = document.querySelector('#datepicker');
        const datepicker = new Datepicker(elem, {
            language: 'ko',
            autohide: true,
            format: 'yyyy-mm-dd',
            beforeShowDay: function (date) {
                const day = date.getDay();

                if ( day === 0 ) {
                    return { classes: 'sunday' };
                } else if ( day === 6 ) {
                    return { classes: 'saturday' };
                }
            }
        });
    </script>

</body>
</html>
```