# Dimension

- 가로/세로 크기 (Width/Height)
    - 요소 자체의 콘텐츠 영역 크기만
    
    ```jsx
    // jQuery
    $('#element').width();
    $('#element').height();
    
    // Vanilla JS
    const el = document.querySelector('#element');
    el.clientWidth;
    el.clientHeight;
    ```
    

- 내부 크기 (innerWidth/innerHeight)
    - 콘텐츠와 패딩(Padding)을 포함한 크기
    
    ```jsx
    // jQuery
    $('#element').innerWidth();
    $('#element').innerHeight();
    
    // Vanilla JS
    // - clientWidth / clientHeight 동일
    ```
    

- 외부 크기 (outerWidth/outerHeight)
    - 패딩, 테두리(Border)를 포함한 크기
    
    ```jsx
    // jQuery
    $('#element').outerWidth();
    $('#element').outerHeight();
    
    // Vanilla JS
    const el = document.querySelector('#element');
    const outerWidth = el.offsetWidth;
    const outerHeight = el.offsetHeight;
    ```
    

- 외부 크기 + 마진 (outerWidth(true))
    
    ```jsx
    // jQuery
    $('#element').outerWidth(true);
    
    // Vanilla JS
    const el = document.querySelector('#element');
    const style = window.getComputedStyle(el);
    const margin = parseFloat(style.marginLeft) + parseFloat(style.marginRight);
    const outerWidthWithMargin = el.offsetWidth + margin;
    ```
    

- 화면 스크롤 관련 (Scroll)
    - 문서 전체 크기
    
    ```jsx
    // jQuery
    $(document).height();
    
    // Vanilla JS
    document.documentElement.scrollHeight;
    ```
    

- 화면 스크롤 관련 (Scroll)
    - 스크롤 위치
    
    ```jsx
    // jQuery
    $(window).scrollTop();
    
    // Vanilla JS
    window.scrollY;
    window.pageYOffset;
    ```