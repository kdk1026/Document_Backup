# Effects

- fadeIn
    
    ```jsx
    // jQuery
    $("button").click(function(){
    	$("#div1").fadeIn();
      $("#div2").fadeIn("slow");
      $("#div3").fadeIn(3000);
    });
    
    // Vanilla JS
    // - 2020년 3월 이전 브라우저에서는 CSS와 함께 처리
    const fadeIn = (el, duration) => {
      // 1. 애니메이션 시작 전 요소를 보이게 설정 (투명도는 0)
      el.style.display = "block"; 
      el.style.opacity = 0;
    
      // 2. 애니메이션 실행
      el.animate(
        [
          { opacity: 0 }, 
          { opacity: 1 }
        ], 
        {
          duration: duration,
          fill: "forwards" // 끝난 상태 유지
        }
      );
    };
    
    document.querySelector("button").addEventListener("click", () => {
      fadeIn(document.getElementById("div1"), 400);
      fadeIn(document.getElementById("div2"), 600);
      fadeIn(document.getElementById("div3"), 3000);
    });
    ```
    

- fadeOut
    
    ```jsx
    // jQuery
    $("button").click(function(){
    	$("#div1").fadeOut();
    	$("#div2").fadeOut("slow");
    	$("#div3").fadeOut(3000);
    });
    
    // Vanilla JS
    // - 2020년 3월 이전 브라우저에서는 CSS와 함께 처리
    const fadeOut = (el, duration) => {
      const animation = el.animate(
        [{ opacity: 1 }, { opacity: 0 }],
        { duration: duration, fill: "forwards" }
      );
    
      // 애니메이션이 끝나면 display를 none으로 변경
      animation.onfinish = () => {
        el.style.display = "none";
      };
    };
    
    document.querySelector("button").addEventListener("click", () => {
      fadeOut(document.getElementById("div1"), 400);
      fadeOut(document.getElementById("div2"), 600);
      fadeOut(document.getElementById("div3"), 3000);
    });
    ```
    

- fadeToggle
    
    ```jsx
    // jQuery
    $("button").click(function(){
    	$("#div1").fadeToggle();
    	$("#div2").fadeToggle("slow");
    	$("#div3").fadeToggle(3000);
    });
    
    // Vanilla JS
    // - 2020년 3월 이전 브라우저에서는 CSS와 함께 처리
    const fadeToggle = (el, duration) => {
      // 현재 요소가 숨겨져 있는지 확인
      const isHidden = window.getComputedStyle(el).display === "none";
    
      if (isHidden) {
        // fadeIn 로직
        el.style.display = "block";
        el.animate(
          [{ opacity: 0 }, { opacity: 1 }],
          { duration: duration, fill: "forwards" }
        );
      } else {
        // fadeOut 로직
        const animation = el.animate(
          [{ opacity: 1 }, { opacity: 0 }],
          { duration: duration, fill: "forwards" }
        );
        
        // 애니메이션 종료 후 display none 처리
        animation.onfinish = () => {
          el.style.display = "none";
        };
      }
    };
    
    document.querySelector("button").addEventListener("click", () => {
      fadeToggle(document.getElementById("div1"), 400);
      fadeToggle(document.getElementById("div2"), 600);
      fadeToggle(document.getElementById("div3"), 3000);
    });
    ```
    

- fadeTo
    
    ```jsx
    // jQuery
    $("button").click(function(){
    	$("#div1").fadeTo("slow", 0.15);
      $("#div2").fadeTo("slow", 0.4);
      $("#div3").fadeTo("slow", 0.7);
    });
    
    // Vanilla JS
    // - 2020년 3월 이전 브라우저에서는 CSS와 함께 처리
    const fadeTo = (el, duration, opacity) => {
      el.animate(
        [
          // 현재 투명도에서 목표 투명도까지
          { opacity: window.getComputedStyle(el).opacity }, 
          { opacity: opacity }
        ], 
        {
          duration: duration,
          fill: "forwards" // 애니메이션이 끝난 후의 투명도를 유지
        }
      );
    };
    
    document.querySelector("button").addEventListener("click", () => {
      fadeTo(document.getElementById("div1"), 600, 0.15);
      fadeTo(document.getElementById("div2"), 600, 0.4);
      fadeTo(document.getElementById("div3"), 600, 0.7);
    });
    ```
    

- slideDown, slideUp, slideToggle
    
    ```jsx
    // jQuery
    $("#flip").click(function(){
    	// $("#panel").slideDown("slow");
    	// $("#panel").slideUp("slow");
    	$("#panel").slideToggle("slow");
    });
    
    // Vanilla JS
    // - 2020년 3월 이전 브라우저에서는 CSS와 함께 처리
    const slide = {
      up: (el, duration) => {
        el.style.overflow = "hidden";
        const animation = el.animate(
          [
            { height: el.offsetHeight + "px" },
            { height: "0px" }
          ],
          { duration: duration, easing: "ease" }
        );
    
        animation.onfinish = () => {
          el.style.display = "none";
        };
      },
    
      down: (el, duration) => {
        el.style.display = "block";
        const targetHeight = el.scrollHeight;
        el.animate(
          [
            { height: "0px" },
            { height: targetHeight + "px" }
          ],
          { duration: duration, easing: "ease" }
        ).onfinish = () => {
          el.style.height = "auto";
        };
      },
    
      toggle: (el, duration) => {
        if (window.getComputedStyle(el).display === "none") {
          slide.down(el, duration);
        } else {
          slide.up(el, duration);
        }
      }
    };
    
    // 버튼 클릭 시 토글 적용 예시
    document.getElementById("flip").addEventListener("click", () => {
      slide.toggle(document.getElementById("panel"), 600);
    });
    ```