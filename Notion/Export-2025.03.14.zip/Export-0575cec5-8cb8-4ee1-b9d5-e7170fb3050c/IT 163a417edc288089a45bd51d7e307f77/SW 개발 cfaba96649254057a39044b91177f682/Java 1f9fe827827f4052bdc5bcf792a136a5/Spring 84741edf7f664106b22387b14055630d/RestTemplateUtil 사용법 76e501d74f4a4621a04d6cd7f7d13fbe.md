# RestTemplateUtil 사용법

[SpringUtil/RestTemplateUtil.java at main · kdk1026/SpringUtil](https://github.com/kdk1026/SpringUtil/blob/main/src/main/java/kr/co/test/util/RestTemplateUtil.java)

- 사용 예제

```java
ResponseEntity<Object> res = RestTemplateUtil.post(false, sUrl, MediaType.APPLICATION_FORM_URLENCODED, null, bodyMap, String.class, null);

if ( HttpStatus.OK == res.getStatusCode() ) {
	String sResJson = res.getBody().toString();

	Map<String, Object> resMap = GsonUtil.FromJson.converterJsonStrToMap(sResJson);

}
```

```java
RegistServiceUsageResVO ret = new RegistServiceUsageResVO();

ResponseEntity<Object> result = IGRestTemplateUtil.post(true, sUrl, MediaType.APPLICATION_JSON, headerMap, vo, RegistServiceUsageResVO.class);

if ( HttpStatus.OK == result.getStatusCode() ) {
	ret = (RegistServiceUsageResVO) result.getBody();
	
}
```

```java
ResponseEntity<Object> result = IGRestTemplateUtil.get(true, sUrl, null, headerMap, ModifyServiceUsageResVO.class, requestId);

if ( HttpStatus.OK == result.getStatusCode() ) {
	ret = (ModifyServiceUsageResVO) result.getBody();

}
```