# 환경 변수 (env-cmd, cross-env)

[env-cmd](%ED%99%98%EA%B2%BD%20%EB%B3%80%EC%88%98%20(env-cmd,%20cross-env)/env-cmd%2045a5a22938f240f08cddd650de2baba4.md)

[cross-env](%ED%99%98%EA%B2%BD%20%EB%B3%80%EC%88%98%20(env-cmd,%20cross-env)/cross-env%2011fa417edc288060ac1ed91bd9cce03a.md)