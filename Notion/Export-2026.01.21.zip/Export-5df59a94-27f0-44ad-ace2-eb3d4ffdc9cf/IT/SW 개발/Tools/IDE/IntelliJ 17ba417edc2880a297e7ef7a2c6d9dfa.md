# IntelliJ

- lombok 설치

- vmoptions 수정

```jsx
#---------------------------------------------
# JVM Heap의 최초/최대 크기 (동일하게 설정 권장)
#--------------------------------------------
-Xms4g
-Xmx4g
```

- vmoptions 추가

```jsx
# 인코딩 설정
-Dfile.encoding=UTF-8
# IPv6 보다 IPv4 우선 인식
-Djava.net.preferIPv4Stack=true
# 클래스 유효성 검사 생략
-Xverify:none
# 컴파일러의 소수점 최적화 기능 작동
-XX:+AggressiveOpts
```

[플러그인 설치](IntelliJ/%ED%94%8C%EB%9F%AC%EA%B7%B8%EC%9D%B8%20%EC%84%A4%EC%B9%98%2017ba417edc288047a0bbd1ec62c8775e.md)

[팁](IntelliJ/%ED%8C%81%201a6a417edc2880d9a86bf12792771750.md)