# jQuery를 바닐라 JS로

- https://whales.tistory.com/62
- jQuery load
    - [https://aosceno.tistory.com/567](https://aosceno.tistory.com/567)

[jQuery extend](jQuery%E1%84%85%E1%85%B3%E1%86%AF%20%E1%84%87%E1%85%A1%E1%84%82%E1%85%B5%E1%86%AF%E1%84%85%E1%85%A1%20JS%E1%84%85%E1%85%A9%201ad4ef5eb097465a8ec88fbccca25f78/jQuery%20extend%20337de1a002354481a378b965a3934b46.md)