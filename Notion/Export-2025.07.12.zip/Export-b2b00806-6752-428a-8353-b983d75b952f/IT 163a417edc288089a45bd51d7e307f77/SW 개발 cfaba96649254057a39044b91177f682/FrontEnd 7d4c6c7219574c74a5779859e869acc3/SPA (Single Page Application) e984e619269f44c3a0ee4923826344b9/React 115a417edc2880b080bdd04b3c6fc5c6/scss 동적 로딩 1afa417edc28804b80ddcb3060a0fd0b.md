# scss 동적 로딩

- 서브 레이아웃에서 부득이하게 어쩔 수 없는 경우

- MuseumMainLayout

```jsx
const [isStyleLoaded, setIsStyleLoaded] = useState(false);

useEffect(() => {
        import('@/styles/museum_style.scss').then(() => {
                setIsStyleLoaded(true);
                styleAction.setMuseumStyleLoaded(dispatch, true);
        });
}, []);

if ( !isStyleLoaded ) {
        return <BarLoader />
}

return (
```

- MuseumRoutes

```jsx
	function MuseumRoutes() {
	    const location = useLocation();
	
	    const isMuseumRoute = location.pathname.startsWith('/museum');
	    
	    const lang = useSelector((state) => state.lang.lang);
	    const isMuseumStyleLoaded = useSelector((state) => state.style.isMuseumStyleLoaded);
	
	    const [isValidUrl, setIsValidUrl] = useState(false);
	
	    const [WBADHM150101_S, setWBADHM150101_S] = useState(null);
	    ...
	
	    // XXX scss가 겹치므로 동적 임포트
	    useEffect(() => {
	        if ( isMuseumStyleLoaded ) {
	            /* 메인 */
	            import("@/museum_pages/main/WBADHM150101_S").then((module) => setWBADHM150101_S(() => module.default));
	        ...
	        }
	    }, [isMuseumStyleLoaded]);
	
	    // XXX URL 치고 들어온 경우, 404에 머물러 있어서 별도 처리
	    useEffect(() => {
	        switch ( location.pathname ) {
	            case '/museum/sitemap':
	                if ( !WBADHM150701_S ) {
	                    import("@/museum_pages/common/sitemap/WBADHM150701_S").then((module) => setWBADHM150701_S(() => module.default));
	                }
	                break;
	            ...
	        
	            default: 
			            setIsValidUrl(true);
	                break;
	        }
	    }, [location.pathname]);
	
	    return (
	            <Routes>
	                <Route path="/museum" element={<MuseumMainLayout />}>
	                    { WBADHM150101_S && <Route index element={<WBADHM150101_S />} /> }
	                    ...
	                </Route>
	                {
	                    (isMuseumRoute && isValidUrl) && (
	                        <Route path="*" element={<EmptyPage />} />
	                    )
	                }
	            </Routes>
	    )
	}

```