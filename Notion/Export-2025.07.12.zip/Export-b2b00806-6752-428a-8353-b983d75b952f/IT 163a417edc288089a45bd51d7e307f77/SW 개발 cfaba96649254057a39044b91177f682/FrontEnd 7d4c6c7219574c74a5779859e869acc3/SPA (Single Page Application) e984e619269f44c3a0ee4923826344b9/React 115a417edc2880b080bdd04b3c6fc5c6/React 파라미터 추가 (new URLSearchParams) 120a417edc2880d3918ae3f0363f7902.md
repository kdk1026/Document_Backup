# React 파라미터 추가 (new URLSearchParams)

```jsx
useEffect(() => {
	if ( initialMenuSeq ) {
		const newSearchParams = new URLSearchParams();
		newSearchParams.set('menuSeq', initialMenuSeq);

		if ( nqrCd ) {
			newSearchParams.set('nqrCd', nqrCd);
		}

		if ( pageIndex ) {
			newSearchParams.set('pageIndex', pageIndex);
		}
		
		if ( q ) {
			newSearchParams.set('q', q);
		}

		navigate({
			pathname: pathname,
			search: newSearchParams.toString(),
		});

		menuNameAction.setMenuSeq(dispatch, initialMenuSeq);
		fetchMenuCntnData();
	}

}, [initialMenuSeq, nqrCd, pageIndex, q, navigate, pathname]);
```