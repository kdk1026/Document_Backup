# env-cmd

- 설치

```bash
npm install env-cmd
```

- / 위치에 파일 생성
    - .env
    - .env.local
    - .env.development
    - .env.production
    
- package.json

```bash
  "scripts": {
    "start": "env-cmd -f .env.local react-scripts start",
		"start:dev": "env-cmd -f .env.development react-scripts start",
		"start:prod": "env-cmd -f .env.production react-scripts start",
    "build": "env-cmd -f .env.local react-scripts build",
		"build:dev": "env-cmd -f .env.development react-scripts build",
		"build:prod": "env-cmd -f .env.production react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  },
```