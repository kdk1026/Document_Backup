# MyBatis

- allowMultiQueries
    - [https://deepweller.tistory.com/28](https://deepweller.tistory.com/28)

[foreach insert](MyBatis/foreach%20insert%20bfdbb712105d4193ac77d8ab1a848dbf.md)