# Promise 예제

```jsx
function createPromise() {
  return new Promise((resolve, reject) => {
    let success = true; // 성공 여부를 나타내는 변수

    if (success) {
      resolve("Promise가 성공했습니다!"); // 성공 시 호출
    } else {
      reject("Promise가 실패했습니다."); // 실패 시 호출
    }
  });
}

// Promise 사용
createPromise()
  .then((message) => {
    console.log(message); // 성공 메시지 출력
  })
  .catch((error) => {
    console.error(error); // 실패 메시지 출력
  });
```