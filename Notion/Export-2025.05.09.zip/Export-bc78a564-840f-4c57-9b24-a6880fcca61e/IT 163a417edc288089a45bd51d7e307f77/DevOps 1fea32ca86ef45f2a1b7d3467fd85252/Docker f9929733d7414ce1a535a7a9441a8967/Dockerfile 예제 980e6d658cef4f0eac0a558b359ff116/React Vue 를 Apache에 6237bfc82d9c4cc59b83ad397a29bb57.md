# React / Vue 를 Apache에

- 선행 과정

```bash
npm run build
```

- Dockerfile

```docker
FROM httpd:2.4
COPY ./build /usr/local/apache2/htdocs/

# httpd.conf 파일 수정: mod_rewrite 주석 해제
RUN sed -i 's/#LoadModule rewrite_module modules\/mod_rewrite.so/LoadModule rewrite_module modules\/mod_rewrite.so/' /usr/local/apache2/conf/httpd.conf

# httpd.conf 파일 수정: AllowOverride None을 AllowOverride All로 변경
RUN sed -i 's/AllowOverride None/AllowOverride All/' /usr/local/apache2/conf/httpd.conf
```

- 빌드 및 실행

```bash
$ docker build -t my-apache2 .
$ docker run -dit --name my-running-app -p 80:80 my-apache2
```