# Nginx 단일 연동 예시

- /etc/nginx/nginx.conf

```jsx
#include /etc/nginx/sites-enabled/*;
```

- /etc/nginx/conf.d/was.conf

```jsx
server {
        listen 80;
        server_name _;

        location / {
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;

                proxy_pass http://127.0.0.1:8080;
                proxy_redirect off;
                charset utf-8;

                proxy_read_timeout 300;
                proxy_buffers 64 16k;
        }
}
```