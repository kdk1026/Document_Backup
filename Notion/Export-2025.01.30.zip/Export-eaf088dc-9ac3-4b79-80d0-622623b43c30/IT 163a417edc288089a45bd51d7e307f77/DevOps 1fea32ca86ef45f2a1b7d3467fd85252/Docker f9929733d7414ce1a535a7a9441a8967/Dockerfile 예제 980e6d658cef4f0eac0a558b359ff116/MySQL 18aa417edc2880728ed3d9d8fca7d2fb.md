# MySQL

- init.sql

```jsx
CREATE DATABASE IF NOT EXISTS world;
CREATE USER 'test'@'%' IDENTIFIED BY 'test1234';
GRANT ALL PRIVILEGES ON world.* TO 'test'@'%';
FLUSH PRIVILEGES;
```

- MySqlDockerfile

```jsx
# Dockerfile
FROM mysql:latest

ENV MYSQL_ROOT_PASSWORD=qwer1234
ENV MYSQL_DATABASE=world

COPY ./init.sql /docker-entrypoint-initdb.d/init.sql
EXPOSE 3306
```

- 빌드 및 실행

```jsx
$ docker build -f MySqlDockerfile -t my-mysql .
$ docker run -d -p 3306:3306 --name my-mysql-container my-mysql

$ docker ps
$ docker exec -it <container_id> mysql -u root -p

접속이 안되는 경우
$ docker restart <container_id>
```