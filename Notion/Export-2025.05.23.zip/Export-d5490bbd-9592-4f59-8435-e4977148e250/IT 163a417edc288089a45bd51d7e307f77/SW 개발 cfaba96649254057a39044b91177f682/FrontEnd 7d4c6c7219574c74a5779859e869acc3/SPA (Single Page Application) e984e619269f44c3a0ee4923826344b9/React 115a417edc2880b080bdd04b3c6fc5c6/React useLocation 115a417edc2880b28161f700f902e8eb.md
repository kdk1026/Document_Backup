# React useLocation

```jsx
const location = useLocation();
const { pathname } = location;

useEffect(() => {
	const searchParams = new URLSearchParams(location.search);
	setMenuSeq(searchParams.get('menuSeq') || '');
}, [location.search]);

useEffect(() => {
	// 코드
}, [menuSeq, nqrCd, pageIndex, q, navigate, pathname]);
```