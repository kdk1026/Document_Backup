# 환경 변수 (env-cmd, cross-env)

[env-cmd](%E1%84%92%E1%85%AA%E1%86%AB%E1%84%80%E1%85%A7%E1%86%BC%20%E1%84%87%E1%85%A7%E1%86%AB%E1%84%89%E1%85%AE%20(env-cmd,%20cross-env)%201f6a417edc28804ca818c470abcb0777/env-cmd%2045a5a22938f240f08cddd650de2baba4.md)

[cross-env](%E1%84%92%E1%85%AA%E1%86%AB%E1%84%80%E1%85%A7%E1%86%BC%20%E1%84%87%E1%85%A7%E1%86%AB%E1%84%89%E1%85%AE%20(env-cmd,%20cross-env)%201f6a417edc28804ca818c470abcb0777/cross-env%2011fa417edc288060ac1ed91bd9cce03a.md)