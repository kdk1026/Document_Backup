# Git 설치

- 패키지 설치

```jsx
// RedHat 계열
$ yum install git

// Debian 계열
$ sudo apt-get update
$ sudo apt-get install git
```

- Git 버전 확인

```jsx
$ git --version
```