# 에러 방지

- 413 에러 방지
    - `/etc/nginx/nginx.conf`
        - Default가 1M 이므로 1M 넘어가면 413 에러 발생
        - 파일 업로드 용량 제한 설정
    
    ```jsx
    http {
        client_max_body_size 100M;
    	
    	...
    }
    ```
    

- 504 에러 방지
    - `server`에 다음 추가
    
    ```jsx
    proxy_connect_timeout 300;
    proxy_send_timeout 300;
    proxy_read_timeout 300;
    send_timeout 300;
    ```