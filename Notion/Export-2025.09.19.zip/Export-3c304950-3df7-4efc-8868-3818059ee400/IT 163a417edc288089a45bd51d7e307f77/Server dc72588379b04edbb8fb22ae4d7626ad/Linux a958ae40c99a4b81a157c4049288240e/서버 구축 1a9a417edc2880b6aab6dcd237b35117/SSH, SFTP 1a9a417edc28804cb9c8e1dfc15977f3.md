# SSH, SFTP

- 패키지 확인

```jsx
// RedHat 계열
$ rpm -qa | grep ssh

// Debian 계열
$ dpkg -l | grep ssh
```

- 패키지 설치

```jsx
// RedHat 계열
$ yum search openssh
$ yum install openssh-server openssh-client

// Debian 계열
$ apt-cache search openssh
$ sudo apt-get install openssh-server openssh-client
```

- 데몬 구동

```jsx
// RedHat 계열
$ systemctl start ssh

// Debian 계열
$ sudo systemctl start ssh
```

- 환경 설정 파일
    - `/etc/ssh/ssh_config`

- 접속 확인
    
    
    | SSH | SFTP | SSH/SFTP |
    | --- | --- | --- |
    | PuTTY | FileZilla | MobaXterm |
    | XSHELL | XFTP |  |

- 방화벽

```jsx
// RedHat 계열
$ firewall-cmd --permanent --add-port=22/tcp
$ firewall-cmd --reload

// Debian 계열
$ sudo ufw allow 22/tcp
$ sudo ufw reload
```