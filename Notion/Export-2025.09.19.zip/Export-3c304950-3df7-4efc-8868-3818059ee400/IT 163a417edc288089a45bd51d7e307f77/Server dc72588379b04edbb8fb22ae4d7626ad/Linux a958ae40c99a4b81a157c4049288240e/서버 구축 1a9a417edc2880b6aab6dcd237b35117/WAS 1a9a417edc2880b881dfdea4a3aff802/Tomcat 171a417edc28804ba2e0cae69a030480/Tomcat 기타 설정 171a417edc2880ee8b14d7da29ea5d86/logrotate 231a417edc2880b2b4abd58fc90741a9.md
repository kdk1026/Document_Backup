# logrotate

```jsx
# Debian 계열
$ sudo apt-get install logrotate

# RedHat 계열
$ sudo yum install logrotate
```

```jsx
$ sudo vi /etc/logrotate.d/tomcat
```

```jsx
/home/kdk/test/apache-tomcat-11.0.2/logs/catalina.out {
    copytruncate
    daily             # 매일 로테이션
    rotate 30         # 30개의 오래된 로그 파일 보관
    compress          # 로테이션된 로그 파일 압축
    missingok         # 로그 파일이 존재하지 않아도 오류 발생시키지 않음
    notifempty        # 로그 파일이 비어 있으면 로테이션하지 않음
    create 640 tomcat tomcat # 새로운 로그 파일 생성 시 권한 및 소유자 설정 (선택 사항)
}
```

```jsx
$ sudo logrotate -f /etc/logrotate.d/tomcat
```