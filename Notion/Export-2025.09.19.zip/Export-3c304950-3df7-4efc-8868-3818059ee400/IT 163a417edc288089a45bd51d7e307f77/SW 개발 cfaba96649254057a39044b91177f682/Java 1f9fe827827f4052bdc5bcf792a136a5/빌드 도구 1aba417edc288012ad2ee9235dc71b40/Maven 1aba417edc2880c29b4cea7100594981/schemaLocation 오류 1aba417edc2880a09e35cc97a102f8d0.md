# schemaLocation 오류

- Downloading external resources is disabled. [DownloadResourceDisabled]
    - https를 http로 변경
    
    ```jsx
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    ```