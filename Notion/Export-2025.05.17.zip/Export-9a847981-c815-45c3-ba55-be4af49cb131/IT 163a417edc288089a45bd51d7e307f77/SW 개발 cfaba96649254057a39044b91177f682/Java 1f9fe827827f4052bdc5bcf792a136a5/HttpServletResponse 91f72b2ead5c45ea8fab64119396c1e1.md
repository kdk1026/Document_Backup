# HttpServletResponse

- JSON 응답

```java
String sJson = GsonUtil.ToJson.converterObjToJsonStr(commonResVo);

response.setContentType(MediaType.APPLICATION_JSON_VALUE);
response.setCharacterEncoding(CommonConstants.Encoding.UTF_8);
response.getWriter().write(sJson);
```

- 에러 응답

```java
response.sendError (HTTP 상태 코드)
response.sendError (HTTP 상태 코드, 오류 메시지)
```