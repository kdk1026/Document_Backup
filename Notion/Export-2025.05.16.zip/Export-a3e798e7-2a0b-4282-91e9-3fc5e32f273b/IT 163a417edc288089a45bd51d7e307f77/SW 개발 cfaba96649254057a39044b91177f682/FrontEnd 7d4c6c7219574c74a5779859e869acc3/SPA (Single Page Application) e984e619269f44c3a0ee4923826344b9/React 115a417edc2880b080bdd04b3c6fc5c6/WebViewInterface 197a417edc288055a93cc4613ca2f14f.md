# WebViewInterface

- WebViewInterface.js

```jsx
import store from "../store";
import { webViewAction } from "../store/actions/WebViewAction";

window.addEventListener("message", (event) => {
    let data;

    try {
        if ( typeof event.data === 'string' ) {
            data = JSON.parse(event.data);
        } else {
            data = event.data;
        }

        webViewAction.setWebViewData(store.dispatch, data);
    
        /*
            // 페이지에서는 자기것만 체크
            const currentPageData = useSelector((state) => state.webView.webViewData);
            if ( currentPageData.page === 'hello' ) {
                console.log("Received from React Native in Hello Page :", currentPageData.message);
            }
        */
    } catch (e) {
        console.error("Failed to parse JSON data:", e);
    }
});

/**
 * 
 * @param {string} page 
 * @param {*} pageData 
 */
export const helloSendDataToReactNative = (page, pageData) => {
    const data = { message: pageData, page: page };

    if ( window.ReactNativeWebView && window.ReactNativeWebView.postMessage ) {
        // React Native WebView에서 실행
        window.ReactNativeWebView.postMessage(JSON.stringify(data));
    } else {
        // 일반 웹브라우저에서 실행
        console.log("Not running inside a React Native WebView");
    }

};
```

- React Native WebView

```jsx
import React, { useRef } from 'react';
import { View, Text, Button } from 'react-native';
import { WebView } from 'react-native-webview';

const App = () => {
  const webviewRef = useRef(null);

  const sendDataToWeb = (page) => {
    const data = { message: 'Hello from React Native!', page: page };
    webviewRef.current.postMessage(JSON.stringify(data));
  };

  const onMessage = (event) => {
    const data = JSON.parse(event.nativeEvent.data);
    console.log('Received from web:', data);

    switch (data.page) {
        case 'hello':
            // 처리
            break;
    
        default:
            break;
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <WebView
        ref={webviewRef}
        source={{ uri: 'http://localhost:3000' }} // React 페이지의 URL
        onMessage={onMessage}
        javaScriptEnabled={true}
        originWhitelist={['*']}
      />
      <Button title="Send Data to Web" onPress={sendDataToWeb} />
    </View>
  );
};

export default App;
```