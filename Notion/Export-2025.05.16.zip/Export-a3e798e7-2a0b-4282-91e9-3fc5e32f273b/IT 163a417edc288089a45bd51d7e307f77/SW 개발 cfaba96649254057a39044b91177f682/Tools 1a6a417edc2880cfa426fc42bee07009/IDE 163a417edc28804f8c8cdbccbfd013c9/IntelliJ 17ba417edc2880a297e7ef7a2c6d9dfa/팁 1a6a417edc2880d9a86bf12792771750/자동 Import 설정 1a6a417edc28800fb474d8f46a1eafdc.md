# 자동 Import 설정

- Editor > General > Auto Import
    - Add umambiguous imports on the fly
    - Optimize imports on the fly (for current project)