# Context 추가 (특정 폴더)

- `conf/server.xml`

```jsx
<Host name="localhost"  appBase="/home/kdk/test/app"
      unpackWARs="true" autoDeploy="true" deployIgnore=".*">

  <Context path="" docBase="BaseFront" reloadable="false" />
  <Context path="/abc" docBase="/home/kdk/test/abc" reloadable="false" />
```