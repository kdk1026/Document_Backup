# index.html에서 환경변수 사용

- vite-plugin-html 설치

```bash
npm install vite-plugin-html
```

- vite.config.js 설정

```jsx
import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import { createHtmlPlugin } from 'vite-plugin-html';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd());

  return {
    plugins: [
      react(),
      createHtmlPlugin({
        inject: {
          data: {
            ncpClientId: env.VITE_NCP_CLIENT_ID
          }
        }
      })
    ]
  }
})
```

- index.html

```html
<script src="https://oapi.map.naver.com/openapi/v3/maps.js?ncpClientId=<%=ncpClientId%>"></script>
```