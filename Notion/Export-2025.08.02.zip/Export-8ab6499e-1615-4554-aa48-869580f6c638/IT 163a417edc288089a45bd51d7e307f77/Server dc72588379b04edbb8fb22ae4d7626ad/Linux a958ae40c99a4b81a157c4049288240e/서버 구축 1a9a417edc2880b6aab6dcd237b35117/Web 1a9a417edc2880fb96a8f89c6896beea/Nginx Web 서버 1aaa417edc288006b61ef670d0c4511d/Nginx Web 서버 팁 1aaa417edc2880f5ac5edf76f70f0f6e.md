# Nginx Web 서버 팁

- Nginx Web 서버 보안 설정
    - [https://m.blog.naver.com/xers1/221848630175](https://m.blog.naver.com/xers1/221848630175)
    
    - 1번 해당 파일
    
    ```jsx
    sites-enabled/default
    ```
    
    - 1번 외에는, 다음 파일에 설정
        - Ubuntu의 경우, 5번 기본 설정되어 있음
        - 6번은 Default가 OFF
    
    ```jsx
    nginx.conf
    ```
    

[http로 접속하면 https로](Nginx%20Web%20%E1%84%89%E1%85%A5%E1%84%87%E1%85%A5%20%E1%84%90%E1%85%B5%E1%86%B8%201aaa417edc2880f5ac5edf76f70f0f6e/http%E1%84%85%E1%85%A9%20%E1%84%8C%E1%85%A5%E1%86%B8%E1%84%89%E1%85%A9%E1%86%A8%E1%84%92%E1%85%A1%E1%84%86%E1%85%A7%E1%86%AB%20https%E1%84%85%E1%85%A9%20231a417edc2880eca35de10bd2c1624a.md)

[에러 방지](Nginx%20Web%20%E1%84%89%E1%85%A5%E1%84%87%E1%85%A5%20%E1%84%90%E1%85%B5%E1%86%B8%201aaa417edc2880f5ac5edf76f70f0f6e/%E1%84%8B%E1%85%A6%E1%84%85%E1%85%A5%20%E1%84%87%E1%85%A1%E1%86%BC%E1%84%8C%E1%85%B5%201aaa417edc288033a3e0ddd0da6decbb.md)

[Server 정보 숨기기](Nginx%20Web%20%E1%84%89%E1%85%A5%E1%84%87%E1%85%A5%20%E1%84%90%E1%85%B5%E1%86%B8%201aaa417edc2880f5ac5edf76f70f0f6e/Server%20%E1%84%8C%E1%85%A5%E1%86%BC%E1%84%87%E1%85%A9%20%E1%84%89%E1%85%AE%E1%86%B7%E1%84%80%E1%85%B5%E1%84%80%E1%85%B5%20218a417edc2880208686f7244cf55239.md)