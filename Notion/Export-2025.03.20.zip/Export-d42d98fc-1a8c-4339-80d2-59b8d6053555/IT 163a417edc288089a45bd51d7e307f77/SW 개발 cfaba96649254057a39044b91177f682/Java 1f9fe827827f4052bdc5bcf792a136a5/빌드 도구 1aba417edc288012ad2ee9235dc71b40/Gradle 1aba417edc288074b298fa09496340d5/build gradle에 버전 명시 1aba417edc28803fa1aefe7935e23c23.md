# build.gradle에 버전 명시

- 버전에 따라 문법이 상이

```jsx
예)
프로젝트 우클릭 > Properties > Gradle
	Override workspace settings 체크
		Specific Gradle version : 7.2
		Java home
```