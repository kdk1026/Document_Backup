# React / Vue 를 Nginx에

- 선행 과정

```bash
npm run build
```

- Dockerfile

```docker
FROM nginx

# Nginx 설정 파일 수정: try_files 추가
RUN sed -i '/location \/ {/a \    try_files $uri $uri/ /index.html;' /etc/nginx/conf.d/default.conf

COPY ./build /usr/share/nginx/html
```

- 빌드 및 실행

```bash
$ docker build -t my-nginx .
$ docker run -dit --name my-running-app -p 80:80 my-nginx
```