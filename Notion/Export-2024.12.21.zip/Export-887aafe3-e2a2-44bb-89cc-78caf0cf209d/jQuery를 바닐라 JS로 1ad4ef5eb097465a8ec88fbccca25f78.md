# jQuery를 바닐라 JS로

- https://whales.tistory.com/62
- jQuery load
    - [https://aosceno.tistory.com/567](https://aosceno.tistory.com/567)

[jQuery extend](jQuery%20extend%20337de1a002354481a378b965a3934b46.md)