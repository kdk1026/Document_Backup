# scss 동적 로딩

- 서브 레이아웃에서 부득이하게 어쩔 수 없는 경우

```jsx
const [isStyleLoaded, setIsStyleLoaded] = useState(false);

useEffect(() => {
        import('@/styles/icerink_style.scss').then(() => {
                setIsStyleLoaded(true);
        });
}, []);

if ( !isStyleLoaded ) {
        return <BarLoader />
}

return (
```