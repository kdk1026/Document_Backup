# lazy()와 Suspense

- lazy를 통해 컴포넌트를 동적으로 import하여 초기 렌더링 지연시간을 어느 정도 줄일 수 있음
- 단독으로는 쓰일 수 없고, Suspense 와 같이 사용
- 예

```jsx
function IcelinkRoutes() {
    const location = useLocation();

    const isIcerinkRoute = location.pathname.startsWith('/icerink');

    const lang = useSelector((state) => state.lang.lang);

    // Lazy로 컴포넌트 로드
    const IcerinkMainLayout = lazy(() => import("../layout/IcerinkMainLayout"));
    const EmptyPage = lazy(() => import("@/pages/EmptyPage"));
    /* 메인 */
    const WBADHM250101_S = lazy(() => import("@/icerink_pages/main/WBADHM250101_S"));
    /* 로그인 */
    const WBLPCM100102_S = lazy(() => import("@/icerink_pages/login/WBLPCM100102_S"));
    const WBADTC200301_S = lazy(() => import("@/icerink_pages/login/WBADTC200301_S"));

    return (
        <>
            <Suspense fallback={<Loader />}>
                <Routes>
                    <Route path="/icerink" element={<IcerinkMainLayout />}>
                        <Route index element={<WBADHM250101_S />} />
                        {/* 로그인 */}
                        <Route path="login">
                            <Route index element={<WBLPCM100102_S />} />
                            <Route path="email" element={<WBADTC200301_S />} />
                            {
                                lang === 'HC01701' ? (
                                    <Route path="" element={<Navigate to="/icerink/login" />} />
                                ) : (
                                    <Route path="" element={<Navigate to="/icerink/login/email" />} />
                                )
                            }
                        </Route>
                    </Route>
                    {
                        isIcerinkRoute &&
                        <Route path="*" element={<EmptyPage />} />
                    }
                </Routes>
            </Suspense>
        </>
    )
}
```