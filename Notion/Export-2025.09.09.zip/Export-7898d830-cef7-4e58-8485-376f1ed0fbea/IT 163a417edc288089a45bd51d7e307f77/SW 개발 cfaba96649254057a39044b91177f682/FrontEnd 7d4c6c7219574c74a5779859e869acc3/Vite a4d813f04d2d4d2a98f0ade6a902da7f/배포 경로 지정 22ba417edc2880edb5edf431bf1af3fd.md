# 배포 경로 지정

```jsx
// vite.config.js
export default defineConfig({
  base: '/museum/',
  build: {
		outDir: 'dist/museum',
  },
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@store': path.resolve(__dirname, './src/store'),
      '@components': path.resolve(__dirname, './src/components')
    }
  }
})
```

- base
    - 배포 경로 지정
        - 모든 리소스에 대한 URL을 `/museum/`으로 시작하도록 생성

- React 추가 설정

```jsx
<BrowserRouter basename="/museum">
```