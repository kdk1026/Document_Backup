# SessionStorage 에 없으면 조회

```jsx
    const LOCALE_DATA_STORAGE_KEY = 'test_user_locale_data';

    const lang = useSelector((state) => state.lang.lang);
    const dispatch = useDispatch();

    const [tempLang, setTempLang] = useState(lang);

    const { apiData: localeList, callApi: fetchLocaleList } = useApi(getUserLocaleList, [lang, LOCALE_DATA_STORAGE_KEY], 'getUserLocaleList' );

    useEffect(() => {
        getLocaleData();
        fetchImageData();
    }, []);

    useEffect(() => {
        if ( localeList ) {
            localeAction.setLocaleData(dispatch, localeList);
            sessionStorage.setItem(LOCALE_DATA_STORAGE_KEY, JSON.stringify(localeList));
        }
    }, [localeList]);

    const getUserLocale = useCallback(() => {
        const userLocaleDataString = sessionStorage.getItem(LOCALE_DATA_STORAGE_KEY);
        if ( userLocaleDataString ) {
            const userLocaleDataObject = JSON.parse(userLocaleDataString);
            localeAction.setLocaleData(dispatch, userLocaleDataObject);
        }
    }, [dispatch]);

    const getLocaleData = useCallback(() => {
        const userLocaleDataString = sessionStorage.getItem(LOCALE_DATA_STORAGE_KEY);
        if ( !userLocaleDataString ) {
            fetchLocaleList();
        } else {
            getUserLocale();
        }
    }, [getUserLocale, fetchLocaleList]);

    useEffect(() => {
        if ( lang !== tempLang ) {
            sessionStorage.removeItem(LOCALE_DATA_STORAGE_KEY);
            setTempLang(lang);
        } else {
            const userLocaleDataString = sessionStorage.getItem(LOCALE_DATA_STORAGE_KEY);
            if ( !userLocaleDataString ) {
                getLocaleData();
            } else {
                getUserLocale();
            }
        }
    }, [tempLang, getLocaleData, getUserLocale, dispatch]);

```