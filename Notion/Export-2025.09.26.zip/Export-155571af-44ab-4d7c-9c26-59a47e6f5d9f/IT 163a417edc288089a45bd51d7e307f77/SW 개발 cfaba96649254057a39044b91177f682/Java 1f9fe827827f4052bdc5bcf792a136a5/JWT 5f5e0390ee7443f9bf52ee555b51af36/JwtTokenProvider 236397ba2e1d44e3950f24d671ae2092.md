# JwtTokenProvider

```java
/**
 * <pre>
 * -----------------------------------
 * 개정이력
 * -----------------------------------
 * 2023. 2. 21. kdk	최초작성
 * </pre>
 *
 *
 * @author kdk
 */
@Slf4j
public class JwtTokenProvider {

	public static class JwtToken {
		public String accessToken;
		public String refreshToken;
	}

// ------------------------------------------------------------------------
// 토큰 생성
// ------------------------------------------------------------------------
	/**
	 * JWT 토큰 생성
	 * @param user
	 * @return
	 */
	public JwtToken generateToken(UserVo user) {
		JwtToken jwtToken = new JwtToken();
		jwtToken.accessToken = this.generateAccessToken(user);
		jwtToken.refreshToken = this.generateRefreshToken(user);
		return jwtToken;
	}

	/**
	 * Access 토큰 생성
	 * @param user
	 * @return
	 */
	public String generateAccessToken(UserVo user) {
		String sExpireTime = SpringBootPropertyUtil.getProperty("jwt.access.expire.minute");
		String sSubject = SpringBootPropertyUtil.getProperty("jwt.subject");
		String sIssuer = SpringBootPropertyUtil.getProperty("jwt.issuer");

		String sSecretKey = SpringBootPropertyUtil.getProperty("jwt.secret.key");
		Key key = Keys.hmacShaKeyFor(sSecretKey.getBytes());

		JwtBuilder builder = Jwts.builder();
		builder.setId(user.getUserId())
			.setIssuedAt(new Date())
			.setSubject(sSubject)
			.setIssuer(sIssuer)
			.signWith(key, SignatureAlgorithm.HS256)
			.setExpiration( this.getExpirationTime(sExpireTime) );

		String sUserJson = GsonUtil.ToJson.converterObjToJsonStr(user);

		builder.claim(CommonConstants.Jwt.USER_INFO, sUserJson);
		builder.claim(CommonConstants.Jwt.TOKEN_KIND, CommonConstants.Jwt.ACCESS_TOKEN);

		return builder.compact();
	}

	/**
	 * Refresh 토큰 생성
	 * @param user
	 * @return
	 */
	public String generateRefreshToken(UserVo user) {
		String sExpireTime = SpringBootPropertyUtil.getProperty("jwt.refresh.expire.minute");
		String sSubject = SpringBootPropertyUtil.getProperty("jwt.subject");
		String sIssuer = SpringBootPropertyUtil.getProperty("jwt.issuer");

		String sSecretKey = SpringBootPropertyUtil.getProperty("jwt.secret.key");
		Key key = Keys.hmacShaKeyFor(sSecretKey.getBytes());

		JwtBuilder builder = Jwts.builder();
		builder.setId(user.getUserId())
			.setIssuedAt(new Date())
			.setSubject(sSubject)
			.setIssuer(sIssuer)
			.signWith(key, SignatureAlgorithm.HS256)
			.setExpiration( this.getExpirationTime(sExpireTime) );

		String sUserJson = GsonUtil.ToJson.converterObjToJsonStr(user);

		builder.claim(CommonConstants.Jwt.USER_INFO, sUserJson);
		builder.claim(CommonConstants.Jwt.TOKEN_KIND, CommonConstants.Jwt.REFRESH_TOKEN);

		return builder.compact();
	}

	/**
	 * 만료일 계산
	 * @param expireIn
	 * @return
	 */
	private Date getExpirationTime(String expireIn) {
		int nExpireIn = Integer.parseInt(expireIn);
		Date date = null;

		LocalDateTime localDateTime = LocalDateTime.now().plusMinutes(nExpireIn);
		date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());

		return date;
    }

// ------------------------------------------------------------------------
// 토큰 가져오기
// ------------------------------------------------------------------------
	/**
	 * 쿠키에서 JWT 토큰 추출
	 * @param request
	 * @return
	 */
	public String getTokenFromCookie(HttpServletRequest request) {
		Cookie cookie = WebUtils.getCookie(request, CommonConstants.Jwt.ACCESS_TOKEN);
		return (cookie == null) ? null : cookie.getValue();
	}

	/**
	 * 헤더에서 JWT 토큰 추출
	 * @param request
	 * @return
	 */
	public String getTokenFromReqHeader(HttpServletRequest request) {
		String sToken = null;

		String sJwtHeader = SpringBootPropertyUtil.getProperty("jwt.header");

		String sAuthorizationHeader = request.getHeader(sJwtHeader);
		String sTokenType = SpringBootPropertyUtil.getProperty("jwt.token.type");

		if ( sTokenType.lastIndexOf(" ") == -1 ) {
			sTokenType = sTokenType + " ";
		}

		if ( !StringUtils.isBlank(sAuthorizationHeader) && sAuthorizationHeader.startsWith(sTokenType) ) {
			sToken = sAuthorizationHeader.substring(sTokenType.length());
		}

		return sToken;
	}

	/**
	 * JWT 토큰 유효성 검증
	 * @param token
	 * @return (0: false, 1: true, 2: expired)
	 */
	public int isValidateJwtToken(String token) {
		String sSecretKey = SpringBootPropertyUtil.getProperty("jwt.secret.key");
		Key key = Keys.hmacShaKeyFor(sSecretKey.getBytes());

		try {
			Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token);
			return 1;

		} catch (SignatureException e) {
			log.error("Invalid JWT signature");

		} catch (MalformedJwtException e) {
			log.error("Invalid JWT token");

		} catch (ExpiredJwtException ex) {
			log.error("Expired JWT token");
			return 2;

		} catch (UnsupportedJwtException ex) {
			log.error("Unsupported JWT token");

		} catch (IllegalArgumentException ex) {
			log.error("JWT claims string is empty.");
		}

		return 0;
	}

	/**
	 * JWT 토큰에서 만료일 가져오기
	 * @param token
	 * @return
	 */
	public Date getExpirationFromJwt(String token) {
		String sSecretKey = SpringBootPropertyUtil.getProperty("jwt.secret.key");
		Key key = Keys.hmacShaKeyFor(sSecretKey.getBytes());

		Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();

		return claims.getExpiration();
	}

	/**
	 * JWT 토큰 유형 가져오기
	 * @param token
	 * @return
	 */
	public String getTokenKind(String token) {
		String sSecretKey = SpringBootPropertyUtil.getProperty("jwt.secret.key");
		Key key = Keys.hmacShaKeyFor(sSecretKey.getBytes());

		Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();

		return (String) claims.get(CommonConstants.Jwt.TOKEN_KIND);
	}

// ------------------------------------------------------------------------
// 토큰에서 로그인 정보 추출
// ------------------------------------------------------------------------
	/**
	 * JWT 토큰에서 로그인 정보 가져오기
	 * @param token
	 * @return
	 */
	public UserVo getAuthUserFromJwt(String token) {
		UserVo user = null;

		if ( !StringUtils.isEmpty(token) ) {
			String sSecretKey = SpringBootPropertyUtil.getProperty("jwt.secret.key");
			Key key = Keys.hmacShaKeyFor(sSecretKey.getBytes());

			Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();

			String sUserJson = String.valueOf(claims.get(CommonConstants.Jwt.USER_INFO));

			Gson gson = new GsonBuilder().disableHtmlEscaping().create();
			user = gson.fromJson(sUserJson, UserVo.class);
		}

		return user;
	}

}
```