# Swagger MultipartFile

<aside>
💡 Spring Boot 3.0 springdoc 기반

</aside>

- MultipartJackson2HttpMessageConverter

```java
@Component
public class MultipartJackson2HttpMessageConverter extends AbstractJackson2HttpMessageConverter {

	public MultipartJackson2HttpMessageConverter(ObjectMapper objectMapper) {
		super(objectMapper, MediaType.APPLICATION_OCTET_STREAM);
	}

	@Override
	public boolean canWrite(Class<?> clazz, MediaType mediaType) {
		return false;
	}

	@Override
	public boolean canWrite(Type type, Class<?> clazz, MediaType mediaType) {
		return false;
	}

	@Override
	protected boolean canWrite(MediaType mediaType) {
		return false;
	}

}
```

- 컨트롤러 메소드

```java
	@Operation(summary = "파일 업로드 테스트")
	@PostMapping(value = "file-upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResVo> fileUpload(@Valid FileTestParamVo fileTestParamVo, BindingResult bindingResult,
		@RequestPart(value = "multipartFile", required = false) MultipartFile multipartFile) {
		CommonResVo commonResVo = new CommonResVo();

		if ( bindingResult.hasErrors() ) {
			commonResVo.setCode(ResponseCodeEnum.NO_INPUT.getCode());
			commonResVo.setMessage( (bindingResult.getAllErrors()).get(0).getDefaultMessage() );
			return ResponseEntity.status(HttpStatus.OK).body(commonResVo);
		}

		testService.uploadFile(fileTestParamVo, multipartFile);

		commonResVo.setCode(ResponseCodeEnum.SUCCESS.getCode());
		commonResVo.setMessage(ResponseCodeEnum.SUCCESS.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(commonResVo);
	}
```