# Swagger (Spring Boot 3)

- 마이그레인 참고 : [https://yeonyeon.tistory.com/322](https://yeonyeon.tistory.com/322)

- pom.xml

```xml
<!-- https://mvnrepository.com/artifact/org.springdoc/springdoc-openapi-starter-webmvc-ui -->
<dependency>
	<groupId>org.springdoc</groupId>
	<artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
	<version>2.5.0</version>
</dependency>
```

- application.properties

```yaml
# Swagger
swagger.title=Base Data API Docs
swagger.description=Base Data API
swagger.version=v0.1
swagger.allow.ip=127.0.0.1,0:0:0:0:0:0:0:1,14.63.82.212
```

- SwaggerProperties

```java
@Getter
@Setter
@ConfigurationProperties("swagger")
public class SwaggerProperties {

	private String title;
	private String description;
	private String version;

}
```

- SwaggerConfiguration

```java
@Configuration
public class SwaggerConfiguration {

	@Bean
	public SwaggerProperties swaggerProperties() {
		return new SwaggerProperties();
	}

	@Bean
	public OpenAPI openAPI(SwaggerProperties swaggerProperties) {
		String jwtSchemeName = "jwtAuth";

		SecurityRequirement securityRequirement = new SecurityRequirement().addList(jwtSchemeName);

		return new OpenAPI()
			.info(apiInfo(swaggerProperties))
			.addSecurityItem(securityRequirement)
			.components(new Components()
					.addSecuritySchemes(jwtSchemeName,
							new SecurityScheme()
							.type(Type.HTTP)
							.scheme("bearer")
							.bearerFormat("JWT")
					)
			);
	}

	private Info apiInfo(SwaggerProperties swaggerProperties) {
		return new Info()
				.version(swaggerProperties.getVersion())
				.title(swaggerProperties.getTitle())
				.description(swaggerProperties.getDescription());
	}

}
```

- SwaggerInterceptor

```java
public class SwaggerInterceptor implements HandlerInterceptor {

	private static final String PRIVATE_IP = "192.168.1";

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		String[] sAllowIps = SpringBootPropertyUtil.getProperty("swagger.allow.ip").split(",");
		List<String> listAllowIp = Arrays.asList(sAllowIps);

		String sReqIp = RequestUtil.getRequestIpAddress(request);

		if ( !listAllowIp.contains(sReqIp) || sReqIp.startsWith(PRIVATE_IP) ) {
			CommonResVo commonResVo = new CommonResVo();
			commonResVo.setCode(ResponseCodeEnum.ERROR.getCode());
			commonResVo.setMessage("유효하지 않은 접근입니다.");

			String sJson = GsonUtil.ToJson.converterObjToJsonStr(commonResVo);

			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
			response.setCharacterEncoding(StandardCharsets.UTF_8.toString());
			response.getWriter().write(sJson);

			return false;
		}

		return true;
	}

}
```

- WebMvcConfig

```java
...

@Override
public void addInterceptors(InterceptorRegistry registry) {
	registry.addInterceptor( new SwaggerInterceptor() )
		.addPathPatterns("/swagger-ui/index.html");
}
```

- Controller 클래스

```java
@Slf4j
@Tag(name = "login", description = "로그인 API")
@RestController
@RequestMapping("/login")
public class LoginController {
```

- Controller 메소드

```java
@Operation(summary = "로그인 테스트", requestBody = @RequestBody(content = @Content(mediaType = MediaType.APPLICATION_FORM_URLENCODED_VALUE, schema = @Schema(allOf = {LoginParamVo.class}))))
@PostMapping("/auth")
public LoginResVo auth(@Valid LoginParamVo loginParamVo, BindingResult bindingResult) {
```

- Param VO 클래스

```java
@Getter
@Setter
@ToString(exclude = "userPw")
public class LoginParamVo {

	@Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = "아이디")
	@NotBlank(message = "아이디는 필수 항목입니다.")
	private String userId;

	@Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = "비밀번호")
	@NotBlank(message = "비밀번호는 필수 항목입니다.")
	private String userPw;

}
```

- Response VO 클래스

```java
@Getter
@Setter
@ToString
public class LoginResVo extends CommonResVo {

	@Schema(description = "토큰 타입", requiredMode = Schema.RequiredMode.REQUIRED)
	private String tokenType;

	@Schema(description = "접근 토큰", requiredMode = Schema.RequiredMode.REQUIRED)
	private String accessToken;

	@Schema(description = "접근 토큰 만료시간", requiredMode = Schema.RequiredMode.REQUIRED)
	private int accessTokenExpireSecond;

	@Schema(description = "아이디", requiredMode = Schema.RequiredMode.REQUIRED)
	private String userId;

}
```