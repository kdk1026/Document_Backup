# Custom Confirm, Alert

```jsx
var action_popup = {
	confirm : function(txt, callback) {
		if ( !txt )  {
			return;
		} else if ( callback == null || typeof callback != 'function' ) {
			return;
		} else {
			$(".pop-confirm").find(".btn-confirm2").on("click", function(){
				$(this).unbind('click');
				callback(true);
				$(".pop-confirm").hide();
			});

			$('#confirmCont').html(txt);
			$(".pop-confirm").show();
		}
	},

	alert: function(txt) {
		if ( !txt ) {
			return;
		} else {
			$('#alertCont').html(txt);
			$(".pop-alert").show();
		}
	}
}
```

```jsx
action_popup.confirm(msg, function(res) {
	if (res) {
		// 확인 시 실행 로직
	}
});
```