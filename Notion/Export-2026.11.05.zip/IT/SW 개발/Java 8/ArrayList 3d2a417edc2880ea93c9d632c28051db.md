# ArrayList

```java
@Getter
@Setter
class UserDto {
	String name;
	int age;
}
```

- 특정 값 제거

```java
userList.removeIf(user -> user.getAge() < 20);
```

- 중단 없는 반복문
    - - 중단이 필요한 경우는 일반적인 향상된 for문 사용

```java
userList.forEach(user -> System.out.prinln(user));

userList.forEach(user -> 메소드(user));

userList.forEach(클래스::메소드);
```

- 정렬

```java
// name 기준 오름차순
userList.sort(Comparator.comparing(UserDto::getName));

// age 기준 내림차순
userList.sort(Comparator.comparing(UserDto::getAge).reversed());

// 다중 조건 정렬
userList.sort(
	Comparator.comparing(UserDto::getName)
		.thenComparing(UserDto::getName).reversed()
);
```

- 필터링
    
    ```java
    // 객체 List 반환
    List<UserDto> adultUserList = userList.stream()
    	.filter(user -> user.getAge() >= 20)
    	.collect(Collectors.toList());
    	
    // 객체 반환
    UserDto result = userList.stream()
    	.filter(user -> "jack".equals(user.getName()))
    	.findAny()
    	.orElse(null);
    	
    // String 반환
    String name = userList.stream()
    	.filter(user -> "jack".equals(user.getName()))
    	.map(UserDto::getName) 
    	.findAny()
    	.orElse("");
    
    // int 반환
    int age = userList.stream()
      .filter(user -> "jack".equals(user.getName())
      .mapToInt(UserDto::getAge)
      .findFirst()
      .orElse(0);
    ```
    

- 객체에서 특정 항목만 List로

```java
List <String> userNameList = userList.stream()
	.map(UserDto::getName)
	.collect(Collectors.toList());
```