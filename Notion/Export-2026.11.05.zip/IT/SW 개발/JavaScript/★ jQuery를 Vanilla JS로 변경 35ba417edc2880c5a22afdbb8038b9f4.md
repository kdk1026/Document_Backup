# ★ jQuery를 Vanilla JS로 변경

- Vanilla JS가 jQuery보다 성능이 더 빠르고 효율적
    - jQuery를 써야 한다면 최소 3.x 이상 사용 권장 (4.0 적극 권장)

- DOM Tree 생성 후, 실행
    
    ```jsx
    // jQuery
    $(document).ready(function() {
      
    });
    
    $(function(){
      
    });
    
    // Vanilla JS
    document.addEventListener('DOMContentLoaded', function() {
        
    });
    ```
    

- 이벤트
    - click, dblclick, mouseenter, mouseleave, mousedown, mouseup, hover, focus, blur
    
    ```jsx
    // jQuery
    $(셀렉터).click(function() {
      
    });
    
    // Vanilla JS
    // - 클래스 등 여러개일 경우, 첫 번째만 동작
    document.querySelector(셀렉터).addEventListener('click', function() {
    
    });
    
    // Vanilla JS
    // - 여러개일 경우
    document.querySelectorAll(셀렉터).forEach((el) => {
    	el.addEventListener('click', function() {
    		
    	});
    });
    ```
    

- 이벤트 바인딩, 이벤트 제거
    
    ```jsx
    // jQuery
    $(셀렉터).on('click', myClickHandler);
    $(셀렉터).off('click', myClickHandler);
    
    // Vanilla JS
    document.querySelector(셀렉터).addEventListener('click', myClickHandler);
    document.querySelector(셀렉터).removeEventListener('click', myClickHandler);
    ```
    
    ```jsx
    /*
    	메모리 누수 방지 및 중복 이벤트 바인딩을 막기 위한 핵심적인 방법으로 권장	
    	페이지가 변경되어서 새로고침 되는 경우는 제거안해도 무방
    */
    
    // jQuery
    $(셀렉터).off('click').on('click', myClickHandler)
    
    // Vanilla JS
    const btn = document.querySelector(셀렉터);
    btn.removeEventListener('click', myClickHandler);
    btn.addEventListener('click', myClickHandler);
    ```
    

- 모든 이벤트 제거하고, 이벤트 바인딩
    
    ```jsx
    // jQuery
    $(셀렉터).off().on('click',funtion(e) {
    
    });
    
    // Vanilla JS
    const el = document.querySelector(셀렉터);
    const clone = el.cloneNode(true);
    
    el.replaceWith(clone);
    
    clone.addEventListener('click', function(e) {
    
    });
    ```
    

- 동적 생성 요소 이벤트
    
    ```jsx
    // jQuery
    $(document).on('click', '.child', function() { 
    
    });
    
    // Vanilla JS
    document.addEventListener('click', (e) => {
    	const target = e.target.closest('.child');
    	if (target) {
    		
    	}
    });
    ```
    

- Trigger
    
    ```java
    // jQuery 방식1
    $(셀렉터).trigger('click');
    
    // jQuery 방식2
    $(셀렉터).click();
    
    // Vanilla JS
    document.querySelector(셀렉터).click();
    ```
    

- Hide and Show
    
    ```jsx
    // jQuery
    $(셀렉터).hide();
    $(셀렉터).show();
    $(셀렉터).toggle();
    
    // Vanilla JS
    document.querySelector(셀렉터).style.display = 'none';
    document.querySelector(셀렉터).style.display = '';
    document.querySelector(셀렉터).style.display = (document.querySelector(셀렉터).style.display === 'none' ? 'block' : 'none')
    ```
    

- Get Content
    
    ```jsx
    // jQuery
    $(셀렉터).text();
    $(셀렉터).html();
    $(셀렉터).val();
    
    $(셀렉터).attr('href');
    
    // Vanilla JS
    document.querySelector(셀렉터).textContent();
    document.querySelector(셀렉터).innerHTML();
    document.querySelector(셀렉터).value();
    
    document.querySelector(셀렉터).getAttribute('href');
    document.querySelector(셀렉터).href;
    ```
    

- Set Content
    
    ```jsx
    // jQuery
    $(셀렉터).text('Hello world!');
    $(셀렉터).html('<b>Hello world!</b>');
    $(셀렉터).val('Dolly Duck');
    
    $(셀렉터).attr('href', 'https://www.w3schools.com');
    
    // Vanilla JS
    document.querySelector(셀렉터).textContent('Hello world!');
    document.querySelector(셀렉터).innerHTML('<b>Hello world!</b>');
    document.querySelector(셀렉터).value('Dolly Duck');
    
    document.querySelector(셀렉터).setAttribute('href', 'https://www.w3schools.com');
    document.querySelector(셀렉터).href = 'https://www.w3schools.com';
    ```
    

- Add Elements
    
    ```jsx
    // jQuery
    $(셀렉터).append('Some appended text.');
    $(셀렉터).prepend('Some prepended text.');
    
    $('Some appended text.').appendTo(셀렉터);
    $('Some prepended text.').prependTo(셀렉터);
    
    $(셀렉터).after('Some text after');
    $(셀렉터).before('Some text before');
    
    // Vanilla JS
    document.querySelector(셀렉터).append('Some appended text.');
    document.querySelector(셀렉터).prepend('Some prepended text.');
    
    document.querySelector(셀렉터).after('Some text after');
    document.querySelector(셀렉터).before('Some text before');
    ```
    

- Inserting HTML Strings
    
    ```jsx
    // jQuery
    $(셀렉터).append('<div>HTML 삽입</div>');
    $(셀렉터).prepend('<div>HTML 삽입</div>');
    
    $(셀렉터).after('<div>HTML 삽입</div>');
    $(셀렉터).before('<div>HTML 삽입</div>');
    ```
    
    ```jsx
    // Vanilla JS
    // - 문자열 HTML 추가 (권장)
    const target = document.querySelector('#target');
    
    // jQuery append HTML 대응
    target.insertAdjacentHTML('beforeend', '<div>HTML 삽입</div>');
    
    // jQuery prepend HTML 대응
    target.insertAdjacentHTML('afterbegin' '<div>HTML 삽입</div>');
    
    // jQuery after HTML 대응
    target.insertAdjacentHTML('afterend', '<p>HTML 삽입</p>');
    
    // jQuery before HTML 대응
    target.insertAdjacentHTML('beforebegin', '<div>HTML 삽입</div>');
    ```
    
    ```jsx
    // Vanilla JS
    // - DOM 노드 생성 및 추가
    
    const newElement = document.createElement('div');
    newElement.textContent = 'HTML 삽입';
    
    document.querySelector(셀렉터).append(newElement);
    document.querySelector(셀렉터).prepend(newElement);
    
    document.querySelector(셀렉터).after(newElement);
    document.querySelector(셀렉터).before(newElement);
    ```
    

- Remove Elements
    
    ```jsx
    // jQuery
    $(셀렉터).remove();
    $(셀렉터).empty();
    
    $('p').remove('.test, .demo');
    
    // Vanilla JS
    document.querySelector(셀렉터).remove();
    document.querySelector(셀렉터).replaceChildren();
    
    document.querySelectorAll('p.test, p.demo').forEach(el => el.remove());
    ```
    

- Get and Set CSS Classes
    
    ```jsx
    // jQuery
    $(셀렉터).addClass("blue");
    $(셀렉터).removeClass("blue");
    $(셀렉터).toggleClass("blue");
    
    // Vanilla JS
    document.querySelector(셀렉터).classList.add("blue");
    document.querySelector(셀렉터).classList.remove('blue');
    document.querySelector(셀렉터).classList.toggle("blue");
    
    // - 여러개일 경우
    document.querySelectorAll(셀렉터).forEach(el => {
        el.classList.add("blue");
    });
    ```
    

- 단일 스타일 변경
    
    ```jsx
    // jQuery
    $(셀렉터).css('color', 'red');
    
    // Vanilla JS
    document.querySelector(셀렉터).style.color = 'red';
    ```
    

- 다중 스타일 변경
    
    ```jsx
    // jQuery
    $(셀렉터).css({'color': 'red', 'font-weight': 'bold'});
    
    // Vanilla JS
    document.querySelectorAll(셀렉터).forEach(e => {
    	e.style.color = 'red';
    	e.style.fontWeight = 'bold';
    });
    ```
    

- Ancestors
    
    ```jsx
    // jQuery
    $(셀렉터).parent();
    $(셀렉터).parents();
    $(셀렉터).parentsUntil("div");
    
    // Vanilla JS
    document.querySelector(셀렉터).parentElement;
    // - parents, parentsUntil는 직접 구현해야 함
    
    ```
    

- Descendants
    
    ```jsx
    // jQuery
    $(셀렉터).children();
    $(셀렉터).children('.child-class');
    $(셀렉터).find('.child');
    $(셀렉터).find('li');
    
    // Vanilla JS
    document.querySelector(셀렉터).children;
    document.querySelector(셀렉터).querySelectorAll(':scope > .active');
    document.querySelector(셀렉터).querySelector('.child');
    document.querySelector(셀렉터).querySelectorAll('li');
    
    ```
    

- Siblings - siblings
    
    ```jsx
    // jQuery
    $(셀렉터).siblings();
    $(셀렉터).siblings('p');
    
    // Vanilla JS
    const siblings = (el, selector) => 
      [...el.parentElement.children].filter(node => 
        node !== el && (!selector || node.matches(selector))
      );
      
    siblings(document.querySelector(셀렉터));
    siblings(document.querySelector(셀렉터), 'p');
    ```
    

- Siblings
    
    ```jsx
    // jQuery
    $(셀렉터).next();
    $(셀렉터).prev();
    
    // Vanilla JS
    document.querySelector(셀렉터).nextElementSibling;
    document.querySelector(셀렉터).previousElementSibling;
    ```
    

- Filtering
    
    ```jsx
    // jQuery
    $(셀렉터).first();
    $(셀렉터).last();
    $(셀렉터).eq(1);
    $('p').filter('.intro');
    $('p').not('.intro');
    
    // Vanilla JS
    document.querySelector(셀렉터);
    document.querySelectorAll(셀렉터).slice(-1)[0];
    document.querySelectorAll(셀렉터)[1];
    document.querySelectorAll('p.intro');
    document.querySelectorAll('p:not(.intro)');
    ```
    

- 요소 복제
    
    ```jsx
    // jQuery
    $(셀렉터).clone();
    $(셀렉터).clone(true); // 자식 요소 복제 O, 이벤트 복제 O
    
    // Vanilla JS
    document.querySelector(셀렉터).cloneNode();
    document.querySelector(셀렉터).cloneNode(true); // 자식 요소 복제 O, 이벤트 복제 X
    ```
    

- extend
    - 얕은 복사
        
        ```jsx
        // jQuery - obj1이 직접 수정됨
        $.extend(obj1, obj2);
        console.log(obj1);
        
        // Vanilla JS - obj1이 직접 수정됨
        Object.assign(obj1, obj2);
        console.log(obj1);
        
        // jQuery - 새로운 객체 반환
        const merged = $.extend({}, obj1, obj2);
        
        // Vanilla JS - 새로운 객체 반환
        const merged = Object.assign({}, obj1, obj2);
        const merged = { ...obj1, ...obj2 };
        ```
        
    
    - 깊은 복사
        
        ```jsx
        // jQuery - obj1이 직접 수정됨
        $.extend(true, obj1, obj2);
        
        // Vanilla JS - obj1이 직접 수정됨
        Object.assign(obj1, structuredClone(obj2));
        
        // jQuery - 새로운 객체 반환
        const merged = $.extend(true, {}, obj1, obj2);
        
        // Vanilla JS - 새로운 객체 반환
        const merged = Object.assign(structuredClone(obj1), structuredClone(obj2));
        ```
        

- each
    
    ```jsx
    const users = [
      { id: 1, name: 'Alice' },
      { id: 2, name: 'Bob' },
      { id: 3, name: 'Charlie' }
    ];
    
    // jQuery
    $.each (users, function (idx, item) {
    	// return false로 중간 중단 가능
    });
    
    // Vanilla JS (중간 중단 필요 없을 시)
    users.forEach(function (item, idx) {
    
    });
    
    // Vanilla JS (중간 중단 필요 시, 인덱스 X)
    for (const item of users) {
    	// break로 중간 중단
    }
    
    // Vanilla JS (중간 중단 필요 시, 인덱스 O)
    for (const [index, item] of users.entries()) {
    	// break로 중간 중단
    }
    ```
    

[Dimension](%E2%98%85%20jQuery%EB%A5%BC%20Vanilla%20JS%EB%A1%9C%20%EB%B3%80%EA%B2%BD/Dimension%2035ca417edc2880d19388d09e1881acaf.md)

[Effects](%E2%98%85%20jQuery%EB%A5%BC%20Vanilla%20JS%EB%A1%9C%20%EB%B3%80%EA%B2%BD/Effects%2035ba417edc288049b91cf9fed2fa617d.md)

- load
    
    ```jsx
    // jQuery (전송 데이터 無)
    $(셀렉터).load(URL, function(response, statusTxt, xhr) {	
    	if(statusTxt === 'error') {
    		console.error(`에러 발생: ${xhr.status} : ${xhr.statusText}`);
    	} else {
    		// load 된 html에 영향 미치는 함수는 여기서 실행
    	}
    });
    
    // Vanilla JS (전송 데이터 無)
    fetch(URL)
    	.then(response => response.text())
    	.then(data => {
    		document.querySelector(셀렉터).innerHTML = data;
    		// load 된 html에 영향 미치는 함수는 여기서 실행
    	})
    	.catch(error => {
    		console.error('에러 발생:', error);
    	});
    ```
    
    ```jsx
    const data = {
    	id: 'user123',
    	mode: 'view'
    };
    
    // jQuery (전송 데이터 有)
    $(셀렉터).load(URL, data, function(response, statusTxt, xhr) {	
    	if(statusTxt === 'error') {
    		console.error(`에러 발생: ${xhr.status} : ${xhr.statusText}`);
    	} else {
    		// load 된 html에 영향 미치는 함수는 여기서 실행
    	}
    });
    
    // Vanilla JS (전송 데이터 有)
    fetch(URL, {
    		method: 'POST'
    		body: JSON.stringify(data)
    	})
    	.then(response => response.text())
    	.then(data => {
    		document.querySelector(셀렉터).innerHTML = data;
    		// load 된 html에 영향 미치는 함수는 여기서 실행
    	})
    	.catch(error => {
    		console.error('에러 발생:', error);
    	});
    ```