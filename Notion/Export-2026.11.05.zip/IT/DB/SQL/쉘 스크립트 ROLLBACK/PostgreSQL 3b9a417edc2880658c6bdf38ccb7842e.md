# PostgreSQL

- db_config.env

```bash
#!/bin/bash

export DB_USER="scott"

# chmod 600 /home/psql/scripts/db_config.env
```

```bash
#!/bin/bash

TODAY=$(date +%Y%m%d)
LOG_FILE="./sql_exec_${TODAY}.log"

# -v ON_ERROR_STOP=1 : 에러 발생 시 즉시 중단 및 쉘에 실패 상태 코드 반환
# --single-transaction (-1) : 전체 스크립트를 하나의 트랜잭션(BEGIN~COMMIT)으로 자동 실행
psql -U "${DB_USER}" -d DB_NAME -v ON_ERROR_STOP=1 --single-transaction > "$LOG_FILE" 2>&1 <<EOF
-- 수행할 DML 구문들 (명시적 BEGIN/COMMIT 생략 가능)

EOF

# 쉘에서 실행 결과 확인
if [ $? -ne 0 ]; then
    echo "[ERROR] SQL 실행 중 에러가 발생하여 자동 ROLLBACK 되었습니다."
    echo "상세 에러 내용 (${LOG_FILE}):"
    echo "--------------------------------------------------"
    cat "$LOG_FILE"
    echo "--------------------------------------------------"
    exit 1
else
    echo "[SUCCESS] SQL 실행 및 COMMIT 성공. (로그 파일: ${LOG_FILE})"
fi
```