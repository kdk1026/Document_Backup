# Oracle

- db_config.env

```bash
#!/bin/bash

export DB_USER="scott"
export DB_PASS="tiger"
export DB_CONN="ORCL"  # TNS 명 또는 호스트:포트/서비스명 (예: 192.168.1.100:1521/ORCL)

# chmod 600 /home/oracle/scripts/db_config.env
```

```bash
#!/bin/bash

TODAY=$(date +%Y%m%d)
LOG_FILE="./sql_exec_${TODAY}.log"

CONFIG_FILE="/home/oracle/scripts/db_config.env"
if [ -f "$CONFIG_FILE" ]; then
	source "$CONFIG_FILE"
else
	echo "오류: 설정 파일을 찾을 수 없습니다 ($CONFIG_FILE)"
	exit 1
fi

sqlplus -s "${DB_USER}/${DB_PASS}@${DB_CONN}" > "$LOG_FILE" 2>&1 <<EOF
-- 1. 에러 발생 시 즉시 ROLLBACK 후 실패(FAILURE) 상태로 종료
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

-- 2. Autocommit 비활성화 (기본값이 OFF이지만 명시)
SET AUTOCOMMIT OFF;

-- 3. 수행할 DML 구문들

-- 4. 모든 구문이 정상 완료되었을 때만 COMMIT
COMMIT;
EXIT 0;
EOF

# 쉘에서 실행 결과 확인
if [ $? -ne 0 ]; then
    echo "[ERROR] SQL 실행 중 에러가 발생하여 ROLLBACK 처리되었습니다."
    echo "상세 에러 내용 (${LOG_FILE}):"
    echo "--------------------------------------------------"
    cat "$LOG_FILE"
    echo "--------------------------------------------------
    exit 1
else
    echo "[SUCCESS] SQL 실행 및 COMMIT 성공. (로그 파일: ${LOG_FILE})"
fi
```

- PL/SQL 방식

```bash
#!/bin/bash

TODAY=$(date +%Y%m%d)
LOG_FILE="./sql_exec_${TODAY}.log"

CONFIG_FILE="/home/oracle/scripts/db_config.env"
if [ -f "$CONFIG_FILE" ]; then
	source "$CONFIG_FILE"
else
	echo "오류: 설정 파일을 찾을 수 없습니다 ($CONFIG_FILE)"
	exit 1
fi

sqlplus -s "${DB_USER}/${DB_PASS}@${DB_CONN}" > "$LOG_FILE" 2>&1 <<EOF
-- 1. 에러 발생 시 즉시 ROLLBACK 후 실패(FAILURE) 상태로 종료
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

-- 2. Autocommit 비활성화 (기본값이 OFF이지만 명시)
SET AUTOCOMMIT OFF;

BEGIN
	-- 3. 수행할 DML 구문들
	COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		-- 에러를 상위(SQL*Plus)로 전달하여 WHENEVER SQLERROR가 감지하게 함
		RAISE;
END;
/

EOF

# 쉘에서 실행 결과 확인
if [ $? -ne 0 ]; then
    echo "[ERROR] SQL 실행 중 에러가 발생하여 ROLLBACK 처리되었습니다."
    echo "상세 에러 내용 (${LOG_FILE}):"
    echo "--------------------------------------------------"
    cat "$LOG_FILE"
    echo "--------------------------------------------------
    exit 1
else
    echo "[SUCCESS] SQL 실행 및 COMMIT 성공. (로그 파일: ${LOG_FILE})"
fi
```