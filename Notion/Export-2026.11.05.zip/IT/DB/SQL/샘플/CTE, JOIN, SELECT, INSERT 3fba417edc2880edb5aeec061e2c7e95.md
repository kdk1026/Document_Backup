# CTE, JOIN, SELECT, INSERT

- 가독성, 재 사용성, 디버깅 편의성, 유지보수 측면 등으로 CTE 방식 권장

```sql
/* Oracle (최신버전) */
INSERT INTO 대상 테이블 (타겟컬럼1, 타겟컬럼2, ...)
WITH CTE_이름 AS (
	SELECT 컬럼1, 컬럼2, ...
	  FROM 테이블
)
SELECT 컬럼1, 컬럼2, ...
  FROM 테이블A AS A
  LEFT JOIN CTE_이름 AS B
    ON A.컬럼 = B.컬럼
;
    
/* Oracle, MS SQL, MySQL, PostgreSQL */
WITH CTE_이름 AS (
	SELECT 컬럼1, 컬럼2, ...
	  FROM 테이블
)
INSERT INTO 대상 테이블 (타겟컬럼1, 타겟컬럼2, ...)
SELECT 컬럼1, 컬럼2, ...
  FROM 테이블A AS A
  LEFT JOIN CTE_이름 AS B
    ON A.컬럼 = B.컬럼
;
```