# multipart/form-data

- 파일

 전송

```jsx
const formData = new FormData();

document.querySelectorAll('[id^="imgFile"]').forEach(function(item, idx) {
	formData.append('imgFile', item.files[0]);
});
```

- 헤더 설정

```jsx
// fetch
fetch("/files/result", {
	method: "POST",
	headers: {
	},
	body: formData
})
.then((res) => {
	return res.json();
})
.then((data) => {
	console.log(data);
})
.catch((err) => {
	console.log(err);
});

// axios
axios.post("/files/result", formData, {
  headers: {
	  "Content-Type": "multipart/form-data"
  },
})
.then((res) => {
	console.log(res);
	console.log(res.data);
})
.catch((err) => {
	console.log(err);
});
```