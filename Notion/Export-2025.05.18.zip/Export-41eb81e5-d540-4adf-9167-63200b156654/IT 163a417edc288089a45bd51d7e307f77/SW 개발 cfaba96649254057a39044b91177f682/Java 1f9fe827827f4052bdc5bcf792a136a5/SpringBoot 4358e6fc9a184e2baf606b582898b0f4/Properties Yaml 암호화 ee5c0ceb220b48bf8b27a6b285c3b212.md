# Properties/Yaml 암호화

- pom.xml

```xml
<!-- https://mvnrepository.com/artifact/com.github.ulisesbocchio/jasypt-spring-boot-starter -->
<dependency>
	<groupId>com.github.ulisesbocchio</groupId>
	<artifactId>jasypt-spring-boot-starter</artifactId>
	<version>3.0.5</version>
</dependency>
```

- application.yml

```yaml
jasypt:
  encryptor:
    password: bMP61ELDPzciXfCwAxpDBI5PRsoiR8yT
    bean: jasyptStringEncryptor
```

- JasyptConfig

```java
@Configuration
public class JasyptConfig {

	@Value("${jasypt.encryptor.password}")
	private String password;

	@Bean("jasyptStringEncryptor")
	public StringEncryptor stringEncryptor() {
		PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        SimpleStringPBEConfig config = new SimpleStringPBEConfig();
        config.setPassword(password);
        config.setPoolSize("1");
        config.setAlgorithm("PBEWithMD5AndDES");
        config.setStringOutputType("base64");
        config.setKeyObtentionIterations("1000");
        config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
        encryptor.setConfig(config);
        return encryptor;
	}

}
```

- JasyptTest

```java
public class JasyptTest {

	@Test
	public void test() {
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword("jasypt.encryptor.password");
		encryptor.setAlgorithm("PBEWithMD5AndDES");

        String encryptedPassword = encryptor.encrypt("평문");
        System.out.println(encryptedPassword);
	}

}
```

- application-local.yml

```yaml
spring:
  first:
    datasource:
      jndi-name: java:comp/env/jdbc/devhp
      password: ENC(jsvTFb59CcSPuVlYrOMQXcOMU8lZv4NL)
  second:
    datasource:
      jndi-name: java:comp/env/jdbc/devci
      password: ENC(pnmC1jLxDHDo3ODCKJZkFT0ub/LdXrDQ)
```

- TomcatEmbdded
    - @Value 로 가져와서 Password 부분에 대입