# HTTP 메소드

- 일반적인 웹 개발 시
    - `GET`, `POST` 만 사용
    - `GET`  : 목록, 상세 페이지
    - `POST` : 등록, 수정, 삭제
    - 개인정보 등 중요 정보가 포함되어 있는 경우, 상세 페이지에 `POST` 사용 고려

- REST API 개발 시
    - `GET`, `POST`, `PUT`, `DELETE` 모두 사용
    - `POST` : 등록
    - `PUT` : 수정
    - `DELETE` : 삭제