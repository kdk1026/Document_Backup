# DocumentBuilderFactory

```java
@Override
	public List<Map<String, Object>> getStockInfoXMLfromTimeConclude() throws Exception {
		List<Map<String, Object>> resultsList = new ArrayList<>();

		final String sApiUrl = SpringBootPropertyUtil.getProperty("koscom.api.url");
		final String sKoscomAuthKey = SpringBootPropertyUtil.getProperty("koscom.auth.key");
		final String sKoscomCode = SpringBootPropertyUtil.getProperty("koscom.code");

		final String sUrl = sApiUrl + "/getStockInfoXML";
		String sReqUrl = sUrl + "?auth_key=" + sKoscomAuthKey + "&code=" + sKoscomCode;

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();

		Document document = builder.parse(sReqUrl);

		Element root = document.getDocumentElement();
		NodeList nodeList = root.getElementsByTagName("TBL_TimeConclude");

		Map<String, Object> map = null;
		for (int i=0; i < nodeList.getLength(); i++) {
			Node item = nodeList.item(i);

			if ( item.getNodeType() == Node.ELEMENT_NODE ) {
				if ( item.getAttributes().getNamedItem("time") != null ) {
					map = new HashMap<>();
					map.put("time", item.getAttributes().getNamedItem("time").getNodeValue());
					map.put("amount", item.getAttributes().getNamedItem("amount").getNodeValue());
					resultsList.add(map);
				}
			}
		}

		return resultsList;
	}
```