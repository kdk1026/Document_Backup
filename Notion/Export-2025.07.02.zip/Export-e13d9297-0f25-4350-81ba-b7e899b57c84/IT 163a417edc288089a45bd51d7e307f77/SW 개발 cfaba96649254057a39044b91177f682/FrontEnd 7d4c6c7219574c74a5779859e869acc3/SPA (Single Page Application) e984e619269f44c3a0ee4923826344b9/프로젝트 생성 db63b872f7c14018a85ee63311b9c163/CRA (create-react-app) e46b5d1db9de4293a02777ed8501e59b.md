# CRA (create-react-app)

```bash
npx create-react-app my-app
```