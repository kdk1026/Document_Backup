# Effects

- Fade
    
    ```jsx
    // jQuery
    $("button").click(function(){
    	$("#div1").fadeIn();
      $("#div2").fadeIn("slow");
      $("#div3").fadeIn(3000);
    });
    
    // Vanilla JS
    // - 2020년 3월 이전 브라우저에서는 CSS와 함께 처리
    document.querySelector("button").addEventListener("click", () => {
      document.querySelector("#div1").animate([
        { opacity: 0 }, { opacity: 1 }
      ], 400).onfinish = (e) => e.target.effect.target.style.opacity = 1;
    
      document.querySelector("#div2").animate([
        { opacity: 0 }, { opacity: 1 }
      ], 600).onfinish = (e) => e.target.effect.target.style.opacity = 1;
    
      document.querySelector("#div3").animate([
        { opacity: 0 }, { opacity: 1 }
      ], 3000).onfinish = (e) => e.target.effect.target.style.opacity = 1;
    });
    ```