# ★ jQuery를 바닐라 JS로 변경

- Vanilla JS가 jQuery보다 성능이 더 빠르고 효율적
    - jQuery를 써야 한다면 최소 3.x 이상 사용 권장 (4.0 적극 권장)

- DOM Tree 생성 후, 실행
    
    ```jsx
    // jQuery
    $(document).ready(function() {
      
    });
    
    $(function(){
      
    });
    
    // Vanilla JS
    document.addEventListener('DOMContentLoaded', function() {
        
    });
    ```
    

- 이벤트
    - click, dblclick, mouseenter, mouseleave, mousedown, mouseup, hover, focus, blur
    
    ```jsx
    // jQuery
    $(셀렉터).click(function() {
      
    });
    
    // Vanilla JS
    // - 클래스 등 여러개일 경우, 첫 번째만 동작
    document.querySelector(셀렉터).addEventListener('click', function() {
    
    });
    
    // Vanilla JS
    // - 여러개일 경우
    document.querySelectorAll(셀렉터).forEach((el) => {
    	el.addEventListener('click', function() {
    		
    	});
    });
    ```
    

- 동적 요소 이벤트
    
    ```jsx
    // jQuery
    $(셀렉터).on('click', '.child', function() { 
    
    });
    
    // Vanilla JS
    document.querySelector(셀렉터).addEventListener('click', (e) => {
    	const target = e.target.closest('.child');
    	if (target) {
    		
    	}
    });
    ```
    

- Hide and Show
    
    ```jsx
    // jQuery
    $(셀렉터).hide();
    $(셀렉터).show();
    $(셀렉터).toggle();
    
    // Vanilla JS
    document.querySelector(셀렉터).style.display = 'none';
    document.querySelector(셀렉터).style.display = 'block';
    document.querySelector(셀렉터).style.display = (document.querySelector(셀렉터).style.display === 'none' ? 'block' : 'none')
    ```
    

- Get Content
    
    ```jsx
    // jQuery
    $(셀렉터).text();
    $(셀렉터).html();
    $(셀렉터).val();
    
    $(셀렉터).attr('href');
    
    // Vanilla JS
    document.querySelector(셀렉터).textContent();
    document.querySelector(셀렉터).innerHTML();
    document.querySelector(셀렉터).value();
    
    document.querySelector(셀렉터).getAttribute('href');
    document.querySelector(셀렉터).href;
    ```
    

- Set Content
    
    ```jsx
    // jQuery
    $(셀렉터).text('Hello world!');
    $(셀렉터).html('<b>Hello world!</b>');
    $(셀렉터).val('Dolly Duck');
    
    $(셀렉터).attr('href', 'https://www.w3schools.com');
    
    // Vanilla JS
    document.querySelector(셀렉터).innerText('Hello world!');
    document.querySelector(셀렉터).innerHTML('<b>Hello world!</b>');
    document.querySelector(셀렉터).value('Dolly Duck');
    
    document.querySelector(셀렉터).setAttribute('href', 'https://www.w3schools.com');
    document.querySelector(셀렉터).href = 'https://www.w3schools.com';
    ```
    

- Add Elements
    
    ```jsx
    // jQuery
    $(셀렉터).append('Some appended text.');
    $(셀렉터).prepend('Some prepended text.');
    
    $(셀렉터).after('Some text after');
    $(셀렉터).before('Some text before');
    
    // Vanilla JS
    document.querySelector(셀렉터).append('Some appended text.');
    document.querySelector(셀렉터).prepend('Some prepended text.');
    
    document.querySelector(셀렉터).after('Some text after');
    document.querySelector(셀렉터).before('Some text before');
    ```
    

- Remove Elements
    
    ```jsx
    // jQuery
    $(셀렉터).remove();
    $(셀렉터).empty();
    
    $('p').remove('.test, .demo');
    
    // Vanilla JS
    document.querySelector(셀렉터).remove();
    document.querySelector(셀렉터).replaceChildren();
    
    document.querySelectorAll('p.test, p.demo').forEach(el => el.remove());
    ```
    

- Get and Set CSS Classes
    
    ```jsx
    // jQuery
    $(셀렉터).addClass("blue");
    $(셀렉터).removeClass("blue");
    $(셀렉터).toggleClass("blue");
    
    // Vanilla JS
    document.querySelector(셀렉터).classList.add("blue");
    document.querySelector(셀렉터).classList.remove('blue');
    document.querySelector(셀렉터).classList.toggle("blue");
    
    // - 여러개일 경우
    document.querySelectorAll(셀렉터).forEach(el => {
        el.classList.add("blue");
    });
    ```
    

- 단일 스타일 변경
    
    ```jsx
    // jQuery
    $(셀렉터).css('color', 'red');
    
    // Vanilla JS
    document.querySelector(셀렉터).style.color = 'red';
    ```
    

- 다중 스타일 변경
    
    ```jsx
    // jQuery
    $(셀렉터).css({'color': 'red', 'font-weight': 'bold'});
    
    // Vanilla JS
    document.querySelectorAll(셀렉터).forEach(e => {
    	e.style.color = 'red';
    	e.style.fontWeight = 'bold';
    });
    ```
    

- Ancestors
    
    ```jsx
    // jQuery
    $(셀렉터).parent();
    $(셀렉터).parents();
    $(셀렉터).parentsUntil("div");
    
    // Vanilla JS
    document.querySelector(셀렉터).parentElement;
    // - parents, parentsUntil는 직접 구현해야 함
    
    ```
    

- Descendants
    
    ```jsx
    // jQuery
    $(셀렉터).children();
    $(셀렉터).children('.child-class');
    $(셀렉터).find('.child');
    $(셀렉터).find('li');
    
    // Vanilla JS
    document.querySelector(셀렉터).children;
    document.querySelector(셀렉터).querySelectorAll(':scope > .active');
    document.querySelector(셀렉터).querySelector('.child');
    document.querySelector(셀렉터).querySelectorAll('li');
    
    ```
    

- Siblings - siblings
    
    ```jsx
    // jQuery
    $(셀렉터).siblings();
    $(셀렉터).siblings('p');
    
    // Vanilla JS
    const siblings = (el, selector) => 
      [...el.parentElement.children].filter(node => 
        node !== el && (!selector || node.matches(selector))
      );
      
    siblings(document.querySelector(셀렉터));
    siblings(document.querySelector(셀렉터), 'p');
    ```
    

- Siblings
    
    ```jsx
    // jQuery
    $(셀렉터).next();
    $(셀렉터).prev();
    
    // Vanilla JS
    document.querySelector(셀렉터).nextElementSibling;
    document.querySelector(셀렉터).previousElementSibling;
    ```
    

- Filtering
    
    ```jsx
    // jQuery
    $(셀렉터).first();
    $(셀렉터).last();
    $(셀렉터).eq(1);
    $('p').filter('.intro');
    $('p').not('.intro');
    
    // Vanilla JS
    document.querySelector(셀렉터);
    document.querySelectorAll(셀렉터).slice(-1)[0];
    document.querySelectorAll(셀렉터)[1];
    document.querySelectorAll('p.intro');
    document.querySelectorAll('p:not(.intro)');
    ```
    

- 요소 복제
    
    ```jsx
    // jQuery
    $(셀렉터).clone();
    $(셀렉터).clone(true);
    
    // Vanilla JS
    document.querySelector(셀렉터).cloneNode();
    document.querySelector(셀렉터).cloneNode(true);
    ```
    

- extend
    
    ```jsx
    // jQuery (얕은 복사)
    const merged = $.extend({}, obj1, obj2);
    
    // Vanilla JS (얕은 복사)
    const merged = Object.assign({}, obj1, obj2);
    const merged = { ...obj1, ...obj2 };
    
    // jQuery (깊은 복사)
    $.extend(true, {}, obj1, obj2)
    
    // Vanilla JS (깊은 복사)
    function extend(target, ...sources) {
        sources.forEach(source => {
            for (let key in source) {
                if (source[key] instanceof Object && key in target) {
                    Object.assign(source[key], extend(target[key], source[key]));
                }
            }
            Object.assign(target, source);
        });
        return target;
    }
    ```
    

[Effects](%E2%98%85%20jQuery%EB%A5%BC%20%EB%B0%94%EB%8B%90%EB%9D%BC%20JS%EB%A1%9C%20%EB%B3%80%EA%B2%BD/Effects%2035ba417edc288049b91cf9fed2fa617d.md)