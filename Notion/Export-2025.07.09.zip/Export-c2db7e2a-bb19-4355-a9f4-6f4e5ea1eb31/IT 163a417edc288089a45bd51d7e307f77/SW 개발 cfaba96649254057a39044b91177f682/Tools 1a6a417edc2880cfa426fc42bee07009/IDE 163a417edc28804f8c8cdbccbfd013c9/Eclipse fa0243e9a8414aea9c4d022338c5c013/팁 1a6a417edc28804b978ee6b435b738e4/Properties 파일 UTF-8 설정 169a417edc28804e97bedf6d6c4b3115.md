# Properties 파일 UTF-8 설정

- Window > Preferences
- General > Content Types
- Text > Java Properties File
- Default encoding을 UTF-8로 변경