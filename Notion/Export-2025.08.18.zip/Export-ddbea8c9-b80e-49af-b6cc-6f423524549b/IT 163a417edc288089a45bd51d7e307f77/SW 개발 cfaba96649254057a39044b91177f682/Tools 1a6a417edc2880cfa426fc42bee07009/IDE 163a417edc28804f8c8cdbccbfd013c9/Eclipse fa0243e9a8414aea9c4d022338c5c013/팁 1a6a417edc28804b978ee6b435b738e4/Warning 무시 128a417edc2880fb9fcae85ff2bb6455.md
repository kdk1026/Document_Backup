# Warning 무시

### YAML Unknown property

- Winodw > Preferences > Spring > Validation > YAML Config Files
    - Unknown property 를 Ignore 로 변경 후, Apply

### pom.xml Duplicating managed version

- Window > Preferences > Maven > Errors/Warnings
    - Overriding managed version 를 Ignore 로 변경 후, Apply

### pom.xml Newer patch version of Spring Boot available

- Winodw > Preferences > Spring > Validation > Versions and Support Ranges
- Update to Latest Patch Version 를 Ignore 로 변경 후, Apply