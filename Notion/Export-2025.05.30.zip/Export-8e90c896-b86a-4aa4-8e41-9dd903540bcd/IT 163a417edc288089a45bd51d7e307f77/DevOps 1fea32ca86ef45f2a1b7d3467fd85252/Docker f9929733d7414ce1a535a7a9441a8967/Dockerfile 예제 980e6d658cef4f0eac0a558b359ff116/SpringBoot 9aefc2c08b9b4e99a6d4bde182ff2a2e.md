# SpringBoot

- 선행 과정
    - 빌드
    
- dockerfile

```docker
# Use an official OpenJDK runtime as a parent image
FROM openjdk:21-oracle

# Set the working directory in the container
WORKDIR /app

# Copy the packaged jar file into the container
COPY target/BaseApi-0.0.1-SNAPSHOT.jar app.jar

# Run the jar file
ENTRYPOINT["java", "-jar", "app.jar", "--spring.profiles.active=dev"]
```

- 빌드 및 실행

```bash
$ docker build -t spring-api -f dockerfile .
$ docker run -d -p 8080:8080 spring-api
```