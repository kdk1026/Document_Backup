# 외장 톰캣 logback-spring

- log4jdbc가 동작 안할 경우, 
PreparedStatement 라도 로깅

- mapper 패키지 debug

```jsx
    <logger name="com.lotteworld.app.mapper" level="debug" additivity="false">
        <appender-ref ref="console"/>
        <appender-ref ref="packageFile"/>
        <appender-ref ref="Error"/>
    </logger>
```