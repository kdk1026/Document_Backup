# HikariCP

- spring.datasource.hikari.max-lifetime
    - MySQL의 show variables like '%timeout';
    - wait_timeout 보다 2~3초 짧게 설정