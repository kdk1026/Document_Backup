# Vite React

```bash
# JavaScript react 템플릿 생성
npm create vite@latest vite-test -- --template react

# TypeScript react-ts 템플릿 생성
npm create vite@latest vite-test -- --template react-ts
```

```bash
npm install
npm run dev
```