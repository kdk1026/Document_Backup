# 비밀번호 분실시

- 윈도우10, 윈도우11
    - [https://papipustory.tistory.com/46](https://papipustory.tistory.com/46)