# cross-env

- 소스 코드 1개로 여러 도메인을 처리해야 할 때 주로 사용

- 설치

```bash
npm install env-cmd
```

- package.json

```json
	...
	
	"scripts": {
	"dev": "cross-env VITE_SITE_GBN=advticketdev env-cmd -f env/.env.local vite --port 3001",
	"dev:advb": "cross-env VITE_SITE_GBN=advbusanticketdev env-cmd -f .env.local vite --port=3000",
	"build": "cross-env VITE_SITE_GBN=advticketdev env-cmd -f env/.env.local vite build",
	"build:advb": "cross-env VITE_SITE_GBN=advbusanticketdev env-cmd -f .env.local vite build",
	},
	
	...
```

- src/config.js

```jsx
if ( import.meta.env.VITE_SITE_GBN === 'advticketdev' ) {
    const profile = import.meta.env.VITE_PROFILE;
    
    getApiUrl = () => {
        if ( profile === 'local' ) {
            return 'http://localhost:8080/api';
        } 
        if ( profile === 'dev' ) {
            return 'http://advticket.lotteworld.com';
        }
    };
}

if ( import.meta.env.VITE_SITE_GBN === 'advbusanticketdev' ) {
    const profile = import.meta.env.VITE_PROFILE;
    
    getApiUrl = () => {
        if ( profile === 'local' ) {
            return 'http://localhost:8080/api';
        } 
        if ( profile === 'dev' ) {
            return 'http://advbusanticketdev.lotteworld.com/api';
        }
    };
}

export { getApiUrl }
```