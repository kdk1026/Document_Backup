# React InputValue 초기화

```jsx
useEffect(() => {
	if ( a24CodeList.length > 0 ) {
		setInputValue((prevState) => ({
			...prevState,
			nqrCsfCd: a24CodeList[0].code
		}));
	}
}, [a24CodeList]);

useEffect(() => {
	if ( !isEmptyObject(authUser) ) {
		const mbzNoC = authUser.mbzNoC;
		const mmtExno = decrypt(authUser.mmtExno);
		const mtlno = decrypt(authUser.mtlno);
		const telNo = mbzNoC + '-' + mmtExno + '-' + mtlno;

		setInputValue((prevState) => ({
			...prevState,
			name: authUser.cstNm,
			telNo: telNo
		}));

		telNoRef.current.disabled = true;
	}
}, [authUser]);
```