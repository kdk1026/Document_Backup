# WebViewInterface

- WebViewInterface.js

```jsx
import CryptoJS from "crypto-js";

const SECRET_KEY = '1234567890';

function generateSignature(type, timestamp) {
    return CryptoJS.SHA256(`${type}${timestamp}${SECRET_KEY}`).toString(CryptoJS.enc.Hex);
}

/**
 * 
 * @param {string} type 
 * @param {*} payload 
 */
export const sendDataToReactNative = (type, payload, callback = null) => {
    const timestamp = Date.now();
    const signature = generateSignature(type, timestamp);

    const message = {
        type: type,
        timestamp: timestamp,
        signature: signature,
        payload: payload
    };

    console.log( 'message : ', JSON.stringify(message) );

    if ( window.ReactNativeWebView && window.ReactNativeWebView.postMessage ) {
		    try {
	        // React Native WebView에서 실행
	        window.ReactNativeWebView.postMessage(JSON.stringify(message));
	        if (callback) callback();
		    } catch (error) {
			    console.error(error);
		    }
    } else {
        // 일반 웹브라우저에서 실행
        console.log("Not running inside a React Native WebView");
    }

};

```

- React Native 웹 뷰로부터 수신

```jsx
  useEffect(() => {
    const handleMessage = (event) => {
      let isKeyboardBridge = false;

      if ( typeof event.data === 'string' ) {
        if ( (event.data).includes('KEYBOARD_STATE_CHANGE') ) {
          isKeyboardBridge = true;
        }
      } else {
        try {
          if ( (JSON.stringify(event.data)).includes('KEYBOARD_STATE_CHANGE') ) {
            isKeyboardBridge = true;
          }
        } catch (e) {
          console.error('Invalid JSON string', e);
        }
      } 

      if ( isKeyboardBridge ) {
        if ( window.ReactNativeWebView && window.ReactNativeWebView.postMessage ) {
          console.log('Message from React Native WebView:', event.data);
        }
    
        try {
          const data = JSON.parse(typeof event.data === 'string' ? event.data : JSON.stringify(event.data));
    
          if ( data.type === 'KEYBOARD_STATE_CHANGE' ) {
            // alert( JSON.stringify(data) );
            if ( data.payload.isShowing ) {
              setIsUpAppKeyboard(true);
            } else {
              setIsUpAppKeyboard(false);
            }
          }
    
        } catch (e) {
          console.error('Invalid JSON string', e);
        }
      }
    };

    window.addEventListener('message', handleMessage);
    document.addEventListener('message', handleMessage);

    return () => {
      window.removeEventListener('message', handleMessage);
      document.removeEventListener('message', handleMessage);
    };
  }, [location]);

```