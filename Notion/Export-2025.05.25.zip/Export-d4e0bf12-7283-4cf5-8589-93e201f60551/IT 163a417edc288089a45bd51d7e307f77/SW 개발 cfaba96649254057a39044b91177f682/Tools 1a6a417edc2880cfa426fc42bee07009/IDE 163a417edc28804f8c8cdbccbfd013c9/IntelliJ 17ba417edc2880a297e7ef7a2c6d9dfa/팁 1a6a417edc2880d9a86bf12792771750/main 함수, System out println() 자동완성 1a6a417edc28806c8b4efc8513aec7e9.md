# main 함수, System.out.println() 자동완성

- main
    - psvm 입력 → Tab키

- System.out.println()
    - sout 입력 → Tab키