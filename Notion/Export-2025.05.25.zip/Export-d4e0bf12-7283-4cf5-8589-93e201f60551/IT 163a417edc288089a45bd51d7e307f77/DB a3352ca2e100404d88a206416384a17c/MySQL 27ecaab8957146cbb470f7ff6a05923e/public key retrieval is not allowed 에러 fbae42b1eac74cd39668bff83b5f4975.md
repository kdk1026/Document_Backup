# public key retrieval is not allowed 에러

- MySQL 8.0 버전부터 보안적인 이슈로 useSSL 옵션에 대한 추가적인 설정이 필요

- 프로그래밍 접속 시, URL 설정
    - useSSL=false / allowPublicKeyRetrieval=true
    
    ```
    jdbc:log4jdbc:mysql://localhost:3306/test-db?useUnicode=true&characterEncoding=utf8&useSSL=false&allowPublicKeyRetrieval=true
    ```
    
    - DBeaver 접속 시
        - Connection Settings 창에서 Driver properties 탭 클릭
        - 화면 우클릭 후, Add new property 클릭
        - 프로퍼티 값 추가 후, 설정
            - allowPublicKeyRetrieval=true
            - useSSL=false