# React 컴포넌트 처리

```jsx
const [components, setComponents] = useState([]);

...

const renderComponent = (comp) => {
	const state = {
		nqrCd,
		setNqrCd,
		pageIndex,
		setPageIndex,
		q,
		setQ
	}

	switch (comp.menuType) {
		case 'A1':
			return <ContentA1Comp data={comp} />;
		case 'Z1':
			return <ContentZ1Comp data={comp} />;
		default:
			return null;
	}
};

...

return (
	<>
		<div>
			{
				components.map((component, index) => (
					<React.Fragment key={index}>
						{renderComponent(component)}
					</React.Fragment>
				))
			}
		</div>
	</>
)
```