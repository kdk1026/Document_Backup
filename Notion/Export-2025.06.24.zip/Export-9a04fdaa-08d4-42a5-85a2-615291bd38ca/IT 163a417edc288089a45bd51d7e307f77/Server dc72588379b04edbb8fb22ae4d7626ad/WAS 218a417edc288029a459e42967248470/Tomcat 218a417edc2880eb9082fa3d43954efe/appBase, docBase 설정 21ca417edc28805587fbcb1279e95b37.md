# appBase, docBase 설정

- `server.xml`
    - 확장자 제외한 war 파일명
    
    ```jsx
    <Host name="localhost"  appBase="webapps"
    	unpackWARs="true" autoDeploy="true">
    	
    <Context path="" docBase="파일명" reloadable="true" />
    ```
    
    ```jsx
    <Host name="localhost"  appBase="c:/test/app"
    	unpackWARs="true" autoDeploy="true">
    	
    <Context path="" docBase="파일명" reloadable="true" />
    ```
    

- `server.xml`
    - 기본적으로 war 파일명 폴더와 ROOT 폴더가 함께 생성됨
    - ROOT 폴더만 적용
    
    ```jsx
    	<Host name="localhost"  appBase="webapps"
    	        unpackWARs="true" autoDeploy="true" deployIgnore=".*">
    ```