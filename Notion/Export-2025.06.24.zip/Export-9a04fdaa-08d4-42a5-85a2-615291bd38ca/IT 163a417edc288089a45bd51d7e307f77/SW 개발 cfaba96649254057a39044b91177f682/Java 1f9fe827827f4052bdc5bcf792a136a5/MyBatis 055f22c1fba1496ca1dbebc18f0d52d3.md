# MyBatis

- allowMultiQueries
    - [https://deepweller.tistory.com/28](https://deepweller.tistory.com/28)

[foreach insert](MyBatis%20055f22c1fba1496ca1dbebc18f0d52d3/foreach%20insert%20bfdbb712105d4193ac77d8ab1a848dbf.md)