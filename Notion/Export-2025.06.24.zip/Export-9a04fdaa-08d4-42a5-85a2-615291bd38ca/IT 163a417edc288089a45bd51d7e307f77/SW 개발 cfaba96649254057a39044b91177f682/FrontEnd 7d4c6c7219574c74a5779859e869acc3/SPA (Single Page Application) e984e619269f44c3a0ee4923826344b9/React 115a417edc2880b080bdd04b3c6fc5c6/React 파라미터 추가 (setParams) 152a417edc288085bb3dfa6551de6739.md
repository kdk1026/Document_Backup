# React 파라미터 추가 (setParams)

```jsx
const [params, setParams] = useSearchParams();

const [pageIndex, setPageIndex] = useState(params.get('pageIndex')||'1');
const [gb, setGb] = useState(params.get('gb')||'');
const [q, setQ] = useState(params.get('q')||'');

...

useEffect(() => {
	setParams({ pageIndex, gb, q });
}, [setParams, pageIndex, gb, q]);
```