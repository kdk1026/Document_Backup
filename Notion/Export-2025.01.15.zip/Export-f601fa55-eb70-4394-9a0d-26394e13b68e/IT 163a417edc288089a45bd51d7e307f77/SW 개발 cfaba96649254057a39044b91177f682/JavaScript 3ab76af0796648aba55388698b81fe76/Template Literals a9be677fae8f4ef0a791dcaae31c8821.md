# Template Literals

- 일반 JavaScript

```jsx
<script>
var n = "Dave";
var s = `Hello ${n}`;
</script>
```

- JSP JavaScript

```jsx
<script>
var n = "Dave";
var s = `Hello \${n}`;  //note the backslash
</script>
```