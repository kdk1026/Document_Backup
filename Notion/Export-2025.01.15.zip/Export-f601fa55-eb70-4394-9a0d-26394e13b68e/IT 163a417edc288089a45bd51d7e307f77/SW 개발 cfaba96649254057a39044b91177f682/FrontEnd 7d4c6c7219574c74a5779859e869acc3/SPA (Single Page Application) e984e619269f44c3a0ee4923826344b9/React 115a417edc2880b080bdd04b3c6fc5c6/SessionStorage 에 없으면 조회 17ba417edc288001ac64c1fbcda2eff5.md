# SessionStorage 에 없으면 조회

```jsx
function TestMainLayout() {
        const LOCALE_DATA_STORAGE_KEY = 'test_user_locale_data';
        
    const navigate = useNavigate();
    const location = useLocation();

    const lang = useSelector((state) => state.lang.lang);
    const dispatch = useDispatch();

    const [tempLang, setTempLang] = useState(lang);

    const fetchData = useCallback(async () => {
        try {
            const res = await getUserLocaleList(lang);
            return res.data;

        } catch (error) {
            if ( error.status === 999 ) {
                navigate("/error-network");
            }
            
            console.log(error);

            return null;
        }
    }, [lang, navigate]);

    const getUserLocale = useCallback(() => {
        const userLocaleDataString = sessionStorage.getItem(LOCALE_DATA_STORAGE_KEY);
        if ( userLocaleDataString ) {
            const userLocaleDataObject = JSON.parse(userLocaleDataString);
            localeAction.setLocaleData(dispatch, userLocaleDataObject);
        }
    }, [dispatch]);

    const getLocaleData = useCallback(() => {
        const userLocaleDataString = sessionStorage.getItem(LOCALE_DATA_STORAGE_KEY);
        if ( !userLocaleDataString ) {
            fetchData().then((res) => {
                if ( res ) {
                    const userLocaleDataObject = res.list;
                    sessionStorage.setItem(LOCALE_DATA_STORAGE_KEY, JSON.stringify(userLocaleDataObject));
                    getUserLocale();
                }
            });
        } else {
            getUserLocale();
        }
    }, [fetchData, getUserLocale]);

    useEffect(() => {
        if ( lang !== tempLang ) {
            sessionStorage.removeItem(LOCALE_DATA_STORAGE_KEY);
            getLocaleData();
            setTempLang(lang);
        } else {
            const userLocaleDataString = sessionStorage.getItem(LOCALE_DATA_STORAGE_KEY);
            if ( !userLocaleDataString ) {
                getLocaleData();
            } else {
                getUserLocale();
            }
        }
    }, [lang, tempLang, getLocaleData, getUserLocale, dispatch]);

}

```