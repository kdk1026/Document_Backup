# Array map 필터링

```jsx
{
        !isEmptyArray(timeItems) && 
        timeItems.filter(item => item.operCsfCd)
        .map((item, index) => (
                <React.Fragment key={index}>
                        {
                                item.operCsfCd === 'HC13103' && (
                                        <dl className={cx(`${page}-operating-time__item`)}>
                                                <dt className={cx(`${page}-operating-time__label`)}>
                                                        {getLocale("MAIN.OPERATING.TEXT3", "실내")}
                                                </dt>
                                                <dd className={cx(`${page}-operating-time__value`)}>
                                                        {item.bgnTmFmt} ~ {item.endTmFmt}
                                                </dd>
                                        </dl>
                                )
                        }
                        {
                                item.operCsfCd === 'HC13102' && (
                                        <dl className={cx(`${page}-operating-time__item`)}>
                                                <dt className={cx(`${page}-operating-time__label`)}>
                                                        {getLocale("MAIN.OPERATING.TEXT4", "실외")}
                                                </dt>
                                                <dd className={cx(`${page}-operating-time__value`)}>
                                                        {item.bgnTmFmt} ~ {item.endTmFmt}
                                                </dd>
                                        </dl>
                                ) 
                        }
                        {
                                item.operCsfCd === 'HC13106' && (
                                        <dl className={cx(`${page}-operating-time__item`)}>
                                                <dt className={cx(`${page}-operating-time__label`)}>
                                                        {getLocale("MAIN.OPERATING.TEXT5", "댕댕")}
                                                </dt>
                                                <dd className={cx(`${page}-operating-time__value`)}>
                                                        {item.bgnTmFmt} ~ {item.endTmFmt}
                                                </dd>
                                        </dl>
                                ) 
                        }
                </React.Fragment>
        ))
}
```