# e.preventDefault, e.stopPropagation

- e.preventDefault();
    - 고유 동작 중단

- e.stopPropagation
    - 상위 엘리먼트들로의 이벤트 전파를 중단